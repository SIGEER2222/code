﻿namespace LibraryUI_rebuild
{
    partial class UIbookadd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UIbookadd));
            this.skinPanel1 = new CCWin.SkinControl.SkinPanel();
            this.bookIds = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.bookimg = new CCWin.SkinControl.SkinPanel();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.page = new System.Windows.Forms.TextBox();
            this.cancle = new CCWin.SkinControl.SkinButton();
            this.sure = new CCWin.SkinControl.SkinButton();
            this.bookname = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.type = new CCWin.SkinControl.SkinTextBox();
            this.pubname = new CCWin.SkinControl.SkinTextBox();
            this.date = new CCWin.SkinControl.SkinTextBox();
            this.autor = new CCWin.SkinControl.SkinTextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.skinLabel20 = new CCWin.SkinControl.SkinLabel();
            this.bookIntro = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel19 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel18 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel17 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel16 = new CCWin.SkinControl.SkinLabel();
            this.skinPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // skinPanel1
            // 
            this.skinPanel1.AutoScroll = true;
            this.skinPanel1.AutoScrollMargin = new System.Drawing.Size(0, 10);
            this.skinPanel1.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel1.Controls.Add(this.bookIds);
            this.skinPanel1.Controls.Add(this.skinLabel6);
            this.skinPanel1.Controls.Add(this.textBox1);
            this.skinPanel1.Controls.Add(this.skinLabel5);
            this.skinPanel1.Controls.Add(this.bookimg);
            this.skinPanel1.Controls.Add(this.skinLabel4);
            this.skinPanel1.Controls.Add(this.page);
            this.skinPanel1.Controls.Add(this.cancle);
            this.skinPanel1.Controls.Add(this.sure);
            this.skinPanel1.Controls.Add(this.bookname);
            this.skinPanel1.Controls.Add(this.skinLabel3);
            this.skinPanel1.Controls.Add(this.skinLabel1);
            this.skinPanel1.Controls.Add(this.skinLabel2);
            this.skinPanel1.Controls.Add(this.type);
            this.skinPanel1.Controls.Add(this.pubname);
            this.skinPanel1.Controls.Add(this.date);
            this.skinPanel1.Controls.Add(this.autor);
            this.skinPanel1.Controls.Add(this.linkLabel1);
            this.skinPanel1.Controls.Add(this.skinLabel20);
            this.skinPanel1.Controls.Add(this.bookIntro);
            this.skinPanel1.Controls.Add(this.skinLabel19);
            this.skinPanel1.Controls.Add(this.skinLabel18);
            this.skinPanel1.Controls.Add(this.skinLabel17);
            this.skinPanel1.Controls.Add(this.skinLabel16);
            this.skinPanel1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanel1.DownBack = null;
            this.skinPanel1.Location = new System.Drawing.Point(4, 28);
            this.skinPanel1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 5);
            this.skinPanel1.MouseBack = null;
            this.skinPanel1.Name = "skinPanel1";
            this.skinPanel1.NormlBack = null;
            this.skinPanel1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.skinPanel1.Size = new System.Drawing.Size(472, 427);
            this.skinPanel1.TabIndex = 0;
            // 
            // bookIds
            // 
            this.bookIds.BackColor = System.Drawing.Color.Transparent;
            this.bookIds.DownBack = null;
            this.bookIds.Icon = null;
            this.bookIds.IconIsButton = false;
            this.bookIds.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIds.IsPasswordChat = '\0';
            this.bookIds.IsSystemPasswordChar = false;
            this.bookIds.Lines = new string[0];
            this.bookIds.Location = new System.Drawing.Point(17, 239);
            this.bookIds.Margin = new System.Windows.Forms.Padding(0);
            this.bookIds.MaxLength = 32767;
            this.bookIds.MinimumSize = new System.Drawing.Size(28, 12);
            this.bookIds.MouseBack = null;
            this.bookIds.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIds.Multiline = false;
            this.bookIds.Name = "bookIds";
            this.bookIds.NormlBack = null;
            this.bookIds.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.bookIds.ReadOnly = false;
            this.bookIds.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bookIds.Size = new System.Drawing.Size(425, 24);
            // 
            // 
            // 
            this.bookIds.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bookIds.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookIds.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.bookIds.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.bookIds.SkinTxt.Name = "BaseText";
            this.bookIds.SkinTxt.Size = new System.Drawing.Size(421, 18);
            this.bookIds.SkinTxt.TabIndex = 0;
            this.bookIds.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIds.SkinTxt.WaterText = "";
            this.bookIds.TabIndex = 87;
            this.bookIds.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bookIds.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIds.WaterText = "";
            this.bookIds.WordWrap = true;
            // 
            // skinLabel6
            // 
            this.skinLabel6.AutoSize = true;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.ForeColor = System.Drawing.Color.Black;
            this.skinLabel6.Location = new System.Drawing.Point(112, 319);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(20, 17);
            this.skinLabel6.TabIndex = 101;
            this.skinLabel6.Text = "元";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(74, 315);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(32, 21);
            this.textBox1.TabIndex = 100;
            // 
            // skinLabel5
            // 
            this.skinLabel5.AutoSize = true;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.ForeColor = System.Drawing.Color.Black;
            this.skinLabel5.Location = new System.Drawing.Point(15, 315);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(44, 17);
            this.skinLabel5.TabIndex = 99;
            this.skinLabel5.Text = "定价：";
            // 
            // bookimg
            // 
            this.bookimg.BackColor = System.Drawing.Color.Transparent;
            this.bookimg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookimg.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.bookimg.DownBack = null;
            this.bookimg.Location = new System.Drawing.Point(302, 13);
            this.bookimg.MouseBack = null;
            this.bookimg.Name = "bookimg";
            this.bookimg.NormlBack = null;
            this.bookimg.Size = new System.Drawing.Size(140, 140);
            this.bookimg.TabIndex = 98;
            // 
            // skinLabel4
            // 
            this.skinLabel4.AutoSize = true;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.ForeColor = System.Drawing.Color.Black;
            this.skinLabel4.Location = new System.Drawing.Point(112, 282);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(20, 17);
            this.skinLabel4.TabIndex = 97;
            this.skinLabel4.Text = "页";
            // 
            // page
            // 
            this.page.Location = new System.Drawing.Point(74, 279);
            this.page.Name = "page";
            this.page.Size = new System.Drawing.Size(32, 21);
            this.page.TabIndex = 96;
            // 
            // cancle
            // 
            this.cancle.BackColor = System.Drawing.Color.Transparent;
            this.cancle.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.cancle.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.cancle.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.cancle.Location = new System.Drawing.Point(273, 610);
            this.cancle.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.cancle.Name = "cancle";
            this.cancle.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.cancle.Size = new System.Drawing.Size(75, 23);
            this.cancle.TabIndex = 95;
            this.cancle.Text = "取消";
            this.cancle.UseVisualStyleBackColor = false;
            this.cancle.Click += new System.EventHandler(this.cancle_Click);
            // 
            // sure
            // 
            this.sure.BackColor = System.Drawing.Color.Transparent;
            this.sure.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.sure.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.sure.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.sure.Location = new System.Drawing.Point(104, 610);
            this.sure.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.sure.Name = "sure";
            this.sure.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.sure.Size = new System.Drawing.Size(75, 23);
            this.sure.TabIndex = 94;
            this.sure.Text = "确认";
            this.sure.UseVisualStyleBackColor = false;
            this.sure.Click += new System.EventHandler(this.sure_Click);
            // 
            // bookname
            // 
            this.bookname.BackColor = System.Drawing.Color.Transparent;
            this.bookname.DownBack = null;
            this.bookname.Icon = null;
            this.bookname.IconIsButton = false;
            this.bookname.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookname.IsPasswordChat = '\0';
            this.bookname.IsSystemPasswordChar = false;
            this.bookname.Lines = new string[0];
            this.bookname.Location = new System.Drawing.Point(59, 13);
            this.bookname.Margin = new System.Windows.Forms.Padding(0);
            this.bookname.MaxLength = 32767;
            this.bookname.MinimumSize = new System.Drawing.Size(28, 12);
            this.bookname.MouseBack = null;
            this.bookname.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookname.Multiline = false;
            this.bookname.Name = "bookname";
            this.bookname.NormlBack = null;
            this.bookname.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.bookname.ReadOnly = false;
            this.bookname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bookname.Size = new System.Drawing.Size(120, 21);
            // 
            // 
            // 
            this.bookname.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bookname.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookname.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.bookname.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.bookname.SkinTxt.Name = "BaseText";
            this.bookname.SkinTxt.Size = new System.Drawing.Size(116, 18);
            this.bookname.SkinTxt.TabIndex = 0;
            this.bookname.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookname.SkinTxt.WaterText = "";
            this.bookname.TabIndex = 87;
            this.bookname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bookname.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookname.WaterText = "";
            this.bookname.WordWrap = true;
            // 
            // skinLabel3
            // 
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.ForeColor = System.Drawing.Color.Black;
            this.skinLabel3.Location = new System.Drawing.Point(16, 282);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(56, 17);
            this.skinLabel3.TabIndex = 93;
            this.skinLabel3.Text = "页码数：";
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.ForeColor = System.Drawing.Color.Black;
            this.skinLabel1.Location = new System.Drawing.Point(15, 207);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(164, 17);
            this.skinLabel1.TabIndex = 92;
            this.skinLabel1.Text = "标识码：（多个以分号分隔）";
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.ForeColor = System.Drawing.Color.Black;
            this.skinLabel2.Location = new System.Drawing.Point(14, 165);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(68, 17);
            this.skinLabel2.TabIndex = 91;
            this.skinLabel2.Text = "出版日期：";
            // 
            // type
            // 
            this.type.BackColor = System.Drawing.Color.Transparent;
            this.type.DownBack = null;
            this.type.Icon = null;
            this.type.IconIsButton = false;
            this.type.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.type.IsPasswordChat = '\0';
            this.type.IsSystemPasswordChar = false;
            this.type.Lines = new string[0];
            this.type.Location = new System.Drawing.Point(62, 125);
            this.type.Margin = new System.Windows.Forms.Padding(0);
            this.type.MaxLength = 32767;
            this.type.MinimumSize = new System.Drawing.Size(28, 12);
            this.type.MouseBack = null;
            this.type.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.type.Multiline = false;
            this.type.Name = "type";
            this.type.NormlBack = null;
            this.type.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.type.ReadOnly = false;
            this.type.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.type.Size = new System.Drawing.Size(120, 21);
            // 
            // 
            // 
            this.type.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.type.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.type.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.type.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.type.SkinTxt.Name = "BaseText";
            this.type.SkinTxt.Size = new System.Drawing.Size(116, 18);
            this.type.SkinTxt.TabIndex = 0;
            this.type.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.type.SkinTxt.WaterText = "";
            this.type.TabIndex = 89;
            this.type.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.type.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.type.WaterText = "";
            this.type.WordWrap = true;
            // 
            // pubname
            // 
            this.pubname.BackColor = System.Drawing.Color.Transparent;
            this.pubname.DownBack = null;
            this.pubname.Icon = null;
            this.pubname.IconIsButton = false;
            this.pubname.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.pubname.IsPasswordChat = '\0';
            this.pubname.IsSystemPasswordChar = false;
            this.pubname.Lines = new string[0];
            this.pubname.Location = new System.Drawing.Point(74, 88);
            this.pubname.Margin = new System.Windows.Forms.Padding(0);
            this.pubname.MaxLength = 32767;
            this.pubname.MinimumSize = new System.Drawing.Size(28, 12);
            this.pubname.MouseBack = null;
            this.pubname.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.pubname.Multiline = false;
            this.pubname.Name = "pubname";
            this.pubname.NormlBack = null;
            this.pubname.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.pubname.ReadOnly = false;
            this.pubname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.pubname.Size = new System.Drawing.Size(120, 21);
            // 
            // 
            // 
            this.pubname.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pubname.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pubname.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.pubname.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.pubname.SkinTxt.Name = "BaseText";
            this.pubname.SkinTxt.Size = new System.Drawing.Size(116, 18);
            this.pubname.SkinTxt.TabIndex = 0;
            this.pubname.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.pubname.SkinTxt.WaterText = "";
            this.pubname.TabIndex = 88;
            this.pubname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.pubname.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.pubname.WaterText = "";
            this.pubname.WordWrap = true;
            // 
            // date
            // 
            this.date.BackColor = System.Drawing.Color.Transparent;
            this.date.DownBack = null;
            this.date.Icon = null;
            this.date.IconIsButton = false;
            this.date.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.date.IsPasswordChat = '\0';
            this.date.IsSystemPasswordChar = false;
            this.date.Lines = new string[0];
            this.date.Location = new System.Drawing.Point(90, 164);
            this.date.Margin = new System.Windows.Forms.Padding(0);
            this.date.MaxLength = 32767;
            this.date.MinimumSize = new System.Drawing.Size(28, 12);
            this.date.MouseBack = null;
            this.date.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.date.Multiline = false;
            this.date.Name = "date";
            this.date.NormlBack = null;
            this.date.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.date.ReadOnly = false;
            this.date.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.date.Size = new System.Drawing.Size(118, 21);
            // 
            // 
            // 
            this.date.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.date.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.date.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.date.SkinTxt.Name = "BaseText";
            this.date.SkinTxt.Size = new System.Drawing.Size(114, 18);
            this.date.SkinTxt.TabIndex = 0;
            this.date.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.date.SkinTxt.WaterText = "";
            this.date.TabIndex = 86;
            this.date.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.date.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.date.WaterText = "";
            this.date.WordWrap = true;
            // 
            // autor
            // 
            this.autor.BackColor = System.Drawing.Color.Transparent;
            this.autor.DownBack = null;
            this.autor.Icon = null;
            this.autor.IconIsButton = false;
            this.autor.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.autor.IsPasswordChat = '\0';
            this.autor.IsSystemPasswordChar = false;
            this.autor.Lines = new string[0];
            this.autor.Location = new System.Drawing.Point(59, 50);
            this.autor.Margin = new System.Windows.Forms.Padding(0);
            this.autor.MaxLength = 32767;
            this.autor.MinimumSize = new System.Drawing.Size(28, 12);
            this.autor.MouseBack = null;
            this.autor.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.autor.Multiline = false;
            this.autor.Name = "autor";
            this.autor.NormlBack = null;
            this.autor.Padding = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.autor.ReadOnly = false;
            this.autor.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.autor.Size = new System.Drawing.Size(120, 21);
            // 
            // 
            // 
            this.autor.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.autor.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.autor.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.autor.SkinTxt.Location = new System.Drawing.Point(2, 2);
            this.autor.SkinTxt.Name = "BaseText";
            this.autor.SkinTxt.Size = new System.Drawing.Size(116, 18);
            this.autor.SkinTxt.TabIndex = 0;
            this.autor.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.autor.SkinTxt.WaterText = "";
            this.autor.TabIndex = 85;
            this.autor.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.autor.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.autor.WaterText = "";
            this.autor.WordWrap = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(353, 172);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(53, 12);
            this.linkLabel1.TabIndex = 84;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "上传封面";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // skinLabel20
            // 
            this.skinLabel20.AutoSize = true;
            this.skinLabel20.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel20.BorderColor = System.Drawing.Color.White;
            this.skinLabel20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel20.ForeColor = System.Drawing.Color.Black;
            this.skinLabel20.Location = new System.Drawing.Point(17, 348);
            this.skinLabel20.Name = "skinLabel20";
            this.skinLabel20.Size = new System.Drawing.Size(44, 17);
            this.skinLabel20.TabIndex = 83;
            this.skinLabel20.Text = "简介：";
            // 
            // bookIntro
            // 
            this.bookIntro.AutoScroll = true;
            this.bookIntro.BackColor = System.Drawing.Color.Transparent;
            this.bookIntro.DownBack = null;
            this.bookIntro.Icon = null;
            this.bookIntro.IconIsButton = false;
            this.bookIntro.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIntro.IsPasswordChat = '\0';
            this.bookIntro.IsSystemPasswordChar = false;
            this.bookIntro.Lines = new string[] {
        "简介"};
            this.bookIntro.Location = new System.Drawing.Point(18, 376);
            this.bookIntro.Margin = new System.Windows.Forms.Padding(0);
            this.bookIntro.MaxLength = 32767;
            this.bookIntro.MinimumSize = new System.Drawing.Size(28, 28);
            this.bookIntro.MouseBack = null;
            this.bookIntro.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIntro.Multiline = true;
            this.bookIntro.Name = "bookIntro";
            this.bookIntro.NormlBack = null;
            this.bookIntro.Padding = new System.Windows.Forms.Padding(5);
            this.bookIntro.ReadOnly = false;
            this.bookIntro.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.bookIntro.Size = new System.Drawing.Size(425, 212);
            // 
            // 
            // 
            this.bookIntro.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bookIntro.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookIntro.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.bookIntro.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.bookIntro.SkinTxt.Multiline = true;
            this.bookIntro.SkinTxt.Name = "BaseText";
            this.bookIntro.SkinTxt.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.bookIntro.SkinTxt.Size = new System.Drawing.Size(415, 202);
            this.bookIntro.SkinTxt.TabIndex = 0;
            this.bookIntro.SkinTxt.Text = "简介";
            this.bookIntro.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIntro.SkinTxt.WaterText = "";
            this.bookIntro.TabIndex = 82;
            this.bookIntro.Text = "简介";
            this.bookIntro.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bookIntro.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIntro.WaterText = "";
            this.bookIntro.WordWrap = true;
            // 
            // skinLabel19
            // 
            this.skinLabel19.AutoSize = true;
            this.skinLabel19.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel19.BorderColor = System.Drawing.Color.White;
            this.skinLabel19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel19.ForeColor = System.Drawing.Color.Black;
            this.skinLabel19.Location = new System.Drawing.Point(15, 125);
            this.skinLabel19.Name = "skinLabel19";
            this.skinLabel19.Size = new System.Drawing.Size(44, 17);
            this.skinLabel19.TabIndex = 81;
            this.skinLabel19.Text = "分类：";
            // 
            // skinLabel18
            // 
            this.skinLabel18.AutoSize = true;
            this.skinLabel18.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel18.BorderColor = System.Drawing.Color.White;
            this.skinLabel18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel18.ForeColor = System.Drawing.Color.Black;
            this.skinLabel18.Location = new System.Drawing.Point(15, 88);
            this.skinLabel18.Name = "skinLabel18";
            this.skinLabel18.Size = new System.Drawing.Size(56, 17);
            this.skinLabel18.TabIndex = 80;
            this.skinLabel18.Text = "出版社：";
            // 
            // skinLabel17
            // 
            this.skinLabel17.AutoSize = true;
            this.skinLabel17.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel17.BorderColor = System.Drawing.Color.White;
            this.skinLabel17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel17.ForeColor = System.Drawing.Color.Black;
            this.skinLabel17.Location = new System.Drawing.Point(15, 50);
            this.skinLabel17.Name = "skinLabel17";
            this.skinLabel17.Size = new System.Drawing.Size(44, 17);
            this.skinLabel17.TabIndex = 79;
            this.skinLabel17.Text = "作者：";
            // 
            // skinLabel16
            // 
            this.skinLabel16.AutoSize = true;
            this.skinLabel16.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel16.BorderColor = System.Drawing.Color.White;
            this.skinLabel16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel16.ForeColor = System.Drawing.Color.Black;
            this.skinLabel16.Location = new System.Drawing.Point(15, 17);
            this.skinLabel16.Name = "skinLabel16";
            this.skinLabel16.Size = new System.Drawing.Size(44, 17);
            this.skinLabel16.TabIndex = 78;
            this.skinLabel16.Text = "书名：";
            // 
            // UIbookadd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(480, 459);
            this.Controls.Add(this.skinPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UIbookadd";
            this.ShowDrawIcon = false;
            this.Text = "";
            this.skinPanel1.ResumeLayout(false);
            this.skinPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private CCWin.SkinControl.SkinPanel skinPanel1;
        private CCWin.SkinControl.SkinTextBox bookIds;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private System.Windows.Forms.TextBox textBox1;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinPanel bookimg;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private System.Windows.Forms.TextBox page;
        private CCWin.SkinControl.SkinButton cancle;
        private CCWin.SkinControl.SkinButton sure;
        private CCWin.SkinControl.SkinTextBox bookname;
        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinTextBox type;
        private CCWin.SkinControl.SkinTextBox pubname;
        private CCWin.SkinControl.SkinTextBox date;
        private CCWin.SkinControl.SkinTextBox autor;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private CCWin.SkinControl.SkinLabel skinLabel20;
        private CCWin.SkinControl.SkinTextBox bookIntro;
        private CCWin.SkinControl.SkinLabel skinLabel19;
        private CCWin.SkinControl.SkinLabel skinLabel18;
        private CCWin.SkinControl.SkinLabel skinLabel17;
        private CCWin.SkinControl.SkinLabel skinLabel16;
    }
}