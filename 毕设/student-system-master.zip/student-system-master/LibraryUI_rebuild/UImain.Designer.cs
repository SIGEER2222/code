﻿namespace LibraryUI_rebuild
{
    partial class UImain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UImain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            this.main = new CCWin.SkinControl.SkinTabControl();
            this.firstpage = new CCWin.SkinControl.SkinTabPage();
            this.firstpageitem = new CCWin.SkinControl.SkinTabControl();
            this.userinfo = new CCWin.SkinControl.SkinTabPage();
            this.lastOnline = new CCWin.SkinControl.SkinLabel();
            this.skinLabel28 = new CCWin.SkinControl.SkinLabel();
            this.qqChange = new CCWin.SkinControl.SkinTextBox();
            this.phoneChange = new CCWin.SkinControl.SkinTextBox();
            this.userNameChange = new CCWin.SkinControl.SkinTextBox();
            this.userInfoCancle = new System.Windows.Forms.LinkLabel();
            this.userInfoSure = new System.Windows.Forms.LinkLabel();
            this.uerInformChange = new System.Windows.Forms.LinkLabel();
            this.personalSign = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel22 = new CCWin.SkinControl.SkinLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.leveltext = new CCWin.SkinControl.SkinLabel();
            this.skinLabel15 = new CCWin.SkinControl.SkinLabel();
            this.qq = new CCWin.SkinControl.SkinLabel();
            this.phone = new CCWin.SkinControl.SkinLabel();
            this.userid = new CCWin.SkinControl.SkinLabel();
            this.username = new CCWin.SkinControl.SkinLabel();
            this.nameshow = new CCWin.SkinControl.SkinLabel();
            this.head = new System.Windows.Forms.Panel();
            this.skinLabel14 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel13 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel12 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel11 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel10 = new CCWin.SkinControl.SkinLabel();
            this.message = new CCWin.SkinControl.SkinTabPage();
            this.skinPanel5 = new CCWin.SkinControl.SkinPanel();
            this.answerRemindPanel = new CCWin.SkinControl.SkinFlowLayoutPanel();
            this.bookstore = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer1 = new CCWin.SkinControl.SkinSplitContainer();
            this.booklist = new CCWin.SkinControl.SkinDataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pubnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbbookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.db_libaryDataSet = new LibraryUI_rebuild.db_libaryDataSet();
            this.skinPanel1 = new CCWin.SkinControl.SkinPanel();
            this.skinButton3 = new CCWin.SkinControl.SkinButton();
            this.booktype = new CCWin.SkinControl.SkinComboBox();
            this.booklistsearch = new CCWin.SkinControl.SkinButton();
            this.booksearch = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel9 = new CCWin.SkinControl.SkinLabel();
            this.skinTreeView1 = new CCWin.SkinControl.SkinTreeView();
            this.skinPanel6 = new CCWin.SkinControl.SkinPanel();
            this.skinPanel2 = new CCWin.SkinControl.SkinPanel();
            this.skinPanel7 = new CCWin.SkinControl.SkinPanel();
            this.commentUpload = new CCWin.SkinControl.SkinButton();
            this.commentText = new CCWin.SkinControl.SkinTextBox();
            this.skinToolStrip3 = new CCWin.SkinControl.SkinToolStrip();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.commentList = new CCWin.SkinControl.SkinFlowLayoutPanel();
            this.bookPicture = new CCWin.SkinControl.SkinPanel();
            this.bookdate = new CCWin.SkinControl.SkinLabel();
            this.bookprice = new CCWin.SkinControl.SkinLabel();
            this.bookpage = new CCWin.SkinControl.SkinLabel();
            this.skinLabel24 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel7 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel23 = new CCWin.SkinControl.SkinLabel();
            this.booksorted = new CCWin.SkinControl.SkinLabel();
            this.bookPubname = new CCWin.SkinControl.SkinLabel();
            this.bookauthor = new CCWin.SkinControl.SkinLabel();
            this.bookName = new CCWin.SkinControl.SkinLabel();
            this.skinLabel21 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel20 = new CCWin.SkinControl.SkinLabel();
            this.bookIntro = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel19 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel18 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel17 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel16 = new CCWin.SkinControl.SkinLabel();
            this.project = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer2 = new CCWin.SkinControl.SkinSplitContainer();
            this.ask_Content = new CCWin.SkinControl.SkinFlowLayoutPanel();
            this.skinPanel12 = new CCWin.SkinControl.SkinPanel();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.questionlistType = new CCWin.SkinControl.SkinComboBox();
            this.skinButton1 = new CCWin.SkinControl.SkinButton();
            this.answer_Content = new CCWin.SkinControl.SkinFlowLayoutPanel();
            this.skinPanel11 = new CCWin.SkinControl.SkinPanel();
            this.Typeword = new CCWin.SkinControl.SkinLabel();
            this.fileName = new CCWin.SkinControl.SkinLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.questionerImg = new CCWin.SkinControl.SkinPanel();
            this.contentword = new CCWin.SkinControl.SkinLabel();
            this.questiondate = new CCWin.SkinControl.SkinLabel();
            this.questioner = new CCWin.SkinControl.SkinLabel();
            this.contenttitle = new CCWin.SkinControl.SkinLabel();
            this.skinPanel10 = new CCWin.SkinControl.SkinPanel();
            this.skinPanelQuestion = new CCWin.SkinControl.SkinPanel();
            this.questionUpload = new CCWin.SkinControl.SkinButton();
            this.questionLoad = new CCWin.SkinControl.SkinLabel();
            this.chooseQusetionFile = new CCWin.SkinControl.SkinButton();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.questionIntro = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.questionType = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.questionTitle = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinPanelAnswer = new CCWin.SkinControl.SkinPanel();
            this.answerUpload = new CCWin.SkinControl.SkinButton();
            this.answerLoad = new CCWin.SkinControl.SkinLabel();
            this.chooseAnswerFile = new CCWin.SkinControl.SkinButton();
            this.skinLabel26 = new CCWin.SkinControl.SkinLabel();
            this.answerIntro = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel27 = new CCWin.SkinControl.SkinLabel();
            this.skinToolStrip4 = new CCWin.SkinControl.SkinToolStrip();
            this.questionshow = new System.Windows.Forms.ToolStripButton();
            this.answershow = new System.Windows.Forms.ToolStripButton();
            this.root = new CCWin.SkinControl.SkinTabPage();
            this.rootcontrol = new CCWin.SkinControl.SkinTabControl();
            this.bookmanage = new CCWin.SkinControl.SkinTabPage();
            this.skinPanel3 = new CCWin.SkinControl.SkinPanel();
            this.skinPanel4 = new CCWin.SkinControl.SkinPanel();
            this.bookinfolist = new CCWin.SkinControl.SkinDataGridView();
            this.bookselect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bookinfoset = new System.Windows.Forms.DataGridViewButtonColumn();
            this.nameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pubnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pagecodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.skinToolStrip1 = new CCWin.SkinControl.SkinToolStrip();
            this.bookadd = new System.Windows.Forms.ToolStripButton();
            this.bookdelet = new System.Windows.Forms.ToolStripButton();
            this.bookrefrsh = new System.Windows.Forms.ToolStripButton();
            this.skinPanel8 = new CCWin.SkinControl.SkinPanel();
            this.bookmanagekey = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.booksearchtype = new CCWin.SkinControl.SkinComboBox();
            this.bookmanagesearch = new CCWin.SkinControl.SkinButton();
            this.projectmanage = new CCWin.SkinControl.SkinTabPage();
            this.skinTabControl1 = new CCWin.SkinControl.SkinTabControl();
            this.questioncontrol = new CCWin.SkinControl.SkinTabPage();
            this.skinToolStrip5 = new CCWin.SkinControl.SkinToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.questionControlList = new CCWin.SkinControl.SkinDataGridView();
            this.select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aboutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uploadTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.questionerIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbquestionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.db_libaryDataSet3 = new LibraryUI_rebuild.db_libaryDataSet3();
            this.answercontrol = new CCWin.SkinControl.SkinTabPage();
            this.usermanage = new CCWin.SkinControl.SkinTabPage();
            this.deletuser = new CCWin.SkinControl.SkinButton();
            this.adduser = new CCWin.SkinControl.SkinButton();
            this.userinfolist = new CCWin.SkinControl.SkinDataGridView();
            this.selectuser = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.levelchange = new System.Windows.Forms.DataGridViewButtonColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qqDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.levelDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.borrownumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.onlineDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tbUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.skinLabel8 = new CCWin.SkinControl.SkinLabel();
            this.fresh = new CCWin.SkinControl.SkinButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.settingmenu = new CCWin.SkinControl.SkinContextMenuStrip();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setting = new CCWin.SkinControl.SkinButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tb_bookTableAdapter = new LibraryUI_rebuild.db_libaryDataSetTableAdapters.tb_bookTableAdapter();
            this.tb_UserTableAdapter = new LibraryUI_rebuild.db_libaryDataSetTableAdapters.tb_UserTableAdapter();
            this.tbbookBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dblibaryDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.db_libaryDataSet1 = new LibraryUI_rebuild.db_libaryDataSet1();
            this.tbquestionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_questionTableAdapter = new LibraryUI_rebuild.db_libaryDataSet1TableAdapters.tb_questionTableAdapter();
            this.tb_questionTableAdapter1 = new LibraryUI_rebuild.db_libaryDataSet3TableAdapters.tb_questionTableAdapter();
            this.main.SuspendLayout();
            this.firstpage.SuspendLayout();
            this.firstpageitem.SuspendLayout();
            this.userinfo.SuspendLayout();
            this.message.SuspendLayout();
            this.skinPanel5.SuspendLayout();
            this.bookstore.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer1)).BeginInit();
            this.skinSplitContainer1.Panel1.SuspendLayout();
            this.skinSplitContainer1.Panel2.SuspendLayout();
            this.skinSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booklist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbbookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet)).BeginInit();
            this.skinPanel1.SuspendLayout();
            this.skinPanel6.SuspendLayout();
            this.skinPanel2.SuspendLayout();
            this.skinPanel7.SuspendLayout();
            this.skinToolStrip3.SuspendLayout();
            this.project.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer2)).BeginInit();
            this.skinSplitContainer2.Panel1.SuspendLayout();
            this.skinSplitContainer2.Panel2.SuspendLayout();
            this.skinSplitContainer2.SuspendLayout();
            this.skinPanel12.SuspendLayout();
            this.skinPanel11.SuspendLayout();
            this.skinPanel10.SuspendLayout();
            this.skinPanelQuestion.SuspendLayout();
            this.skinPanelAnswer.SuspendLayout();
            this.skinToolStrip4.SuspendLayout();
            this.root.SuspendLayout();
            this.rootcontrol.SuspendLayout();
            this.bookmanage.SuspendLayout();
            this.skinPanel3.SuspendLayout();
            this.skinPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookinfolist)).BeginInit();
            this.skinToolStrip1.SuspendLayout();
            this.skinPanel8.SuspendLayout();
            this.projectmanage.SuspendLayout();
            this.skinTabControl1.SuspendLayout();
            this.questioncontrol.SuspendLayout();
            this.skinToolStrip5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.questionControlList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquestionBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet3)).BeginInit();
            this.usermanage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userinfolist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbUserBindingSource)).BeginInit();
            this.settingmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbbookBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibaryDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquestionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // main
            // 
            this.main.AnimatorType = CCWin.SkinControl.AnimationType.HorizSlide;
            this.main.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.main.Controls.Add(this.firstpage);
            this.main.Controls.Add(this.bookstore);
            this.main.Controls.Add(this.project);
            this.main.Controls.Add(this.root);
            this.main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main.HeadBack = null;
            this.main.ImageList = this.imageList1;
            this.main.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.main.ItemSize = new System.Drawing.Size(120, 36);
            this.main.Location = new System.Drawing.Point(4, 28);
            this.main.Name = "main";
            this.main.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("main.PageArrowDown")));
            this.main.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("main.PageArrowHover")));
            this.main.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("main.PageCloseHover")));
            this.main.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("main.PageCloseNormal")));
            this.main.PageDown = ((System.Drawing.Image)(resources.GetObject("main.PageDown")));
            this.main.PageDownTxtColor = System.Drawing.Color.White;
            this.main.PageHover = ((System.Drawing.Image)(resources.GetObject("main.PageHover")));
            this.main.PageHoverTxtColor = System.Drawing.Color.White;
            this.main.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.main.PageNorml = null;
            this.main.PageNormlTxtColor = System.Drawing.Color.White;
            this.main.SelectedIndex = 3;
            this.main.Size = new System.Drawing.Size(984, 583);
            this.main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.main.TabIndex = 0;
            this.main.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.main_Selecting);
            // 
            // firstpage
            // 
            this.firstpage.BackColor = System.Drawing.Color.White;
            this.firstpage.Controls.Add(this.firstpageitem);
            this.firstpage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.firstpage.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.firstpage.ForeColor = System.Drawing.Color.White;
            this.firstpage.ImageIndex = 3;
            this.firstpage.Location = new System.Drawing.Point(0, 36);
            this.firstpage.Name = "firstpage";
            this.firstpage.Size = new System.Drawing.Size(984, 547);
            this.firstpage.TabIndex = 0;
            this.firstpage.TabItemImage = null;
            this.firstpage.Text = "首页";
            // 
            // firstpageitem
            // 
            this.firstpageitem.AnimatorType = CCWin.SkinControl.AnimationType.HorizSlide;
            this.firstpageitem.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.firstpageitem.Controls.Add(this.userinfo);
            this.firstpageitem.Controls.Add(this.message);
            this.firstpageitem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.firstpageitem.HeadBack = null;
            this.firstpageitem.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.firstpageitem.ItemSize = new System.Drawing.Size(70, 36);
            this.firstpageitem.Location = new System.Drawing.Point(0, 0);
            this.firstpageitem.Name = "firstpageitem";
            this.firstpageitem.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageArrowDown")));
            this.firstpageitem.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageArrowHover")));
            this.firstpageitem.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageCloseHover")));
            this.firstpageitem.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageCloseNormal")));
            this.firstpageitem.PageDown = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageDown")));
            this.firstpageitem.PageHover = ((System.Drawing.Image)(resources.GetObject("firstpageitem.PageHover")));
            this.firstpageitem.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.firstpageitem.PageNorml = null;
            this.firstpageitem.SelectedIndex = 0;
            this.firstpageitem.Size = new System.Drawing.Size(984, 547);
            this.firstpageitem.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.firstpageitem.TabIndex = 0;
            this.firstpageitem.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.firstpageitem_Selecting);
            // 
            // userinfo
            // 
            this.userinfo.BackColor = System.Drawing.Color.White;
            this.userinfo.Controls.Add(this.lastOnline);
            this.userinfo.Controls.Add(this.skinLabel28);
            this.userinfo.Controls.Add(this.qqChange);
            this.userinfo.Controls.Add(this.phoneChange);
            this.userinfo.Controls.Add(this.userNameChange);
            this.userinfo.Controls.Add(this.userInfoCancle);
            this.userinfo.Controls.Add(this.userInfoSure);
            this.userinfo.Controls.Add(this.uerInformChange);
            this.userinfo.Controls.Add(this.personalSign);
            this.userinfo.Controls.Add(this.skinLabel22);
            this.userinfo.Controls.Add(this.linkLabel1);
            this.userinfo.Controls.Add(this.leveltext);
            this.userinfo.Controls.Add(this.skinLabel15);
            this.userinfo.Controls.Add(this.qq);
            this.userinfo.Controls.Add(this.phone);
            this.userinfo.Controls.Add(this.userid);
            this.userinfo.Controls.Add(this.username);
            this.userinfo.Controls.Add(this.nameshow);
            this.userinfo.Controls.Add(this.head);
            this.userinfo.Controls.Add(this.skinLabel14);
            this.userinfo.Controls.Add(this.skinLabel13);
            this.userinfo.Controls.Add(this.skinLabel12);
            this.userinfo.Controls.Add(this.skinLabel11);
            this.userinfo.Controls.Add(this.skinLabel10);
            this.userinfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userinfo.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userinfo.Location = new System.Drawing.Point(0, 36);
            this.userinfo.Name = "userinfo";
            this.userinfo.Size = new System.Drawing.Size(984, 511);
            this.userinfo.TabIndex = 0;
            this.userinfo.TabItemImage = null;
            this.userinfo.Text = "用户信息";
            // 
            // lastOnline
            // 
            this.lastOnline.AutoSize = true;
            this.lastOnline.BackColor = System.Drawing.Color.Transparent;
            this.lastOnline.BorderColor = System.Drawing.Color.Transparent;
            this.lastOnline.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lastOnline.ForeColor = System.Drawing.Color.Black;
            this.lastOnline.Location = new System.Drawing.Point(408, 54);
            this.lastOnline.Name = "lastOnline";
            this.lastOnline.Size = new System.Drawing.Size(0, 17);
            this.lastOnline.TabIndex = 33;
            // 
            // skinLabel28
            // 
            this.skinLabel28.AutoSize = true;
            this.skinLabel28.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel28.BorderColor = System.Drawing.Color.White;
            this.skinLabel28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel28.ForeColor = System.Drawing.Color.Black;
            this.skinLabel28.Location = new System.Drawing.Point(316, 54);
            this.skinLabel28.Name = "skinLabel28";
            this.skinLabel28.Size = new System.Drawing.Size(92, 17);
            this.skinLabel28.TabIndex = 32;
            this.skinLabel28.Text = "上次登录时间：";
            // 
            // qqChange
            // 
            this.qqChange.BackColor = System.Drawing.Color.Transparent;
            this.qqChange.DownBack = null;
            this.qqChange.Icon = null;
            this.qqChange.IconIsButton = false;
            this.qqChange.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.qqChange.IsPasswordChat = '\0';
            this.qqChange.IsSystemPasswordChar = false;
            this.qqChange.Lines = new string[0];
            this.qqChange.Location = new System.Drawing.Point(99, 227);
            this.qqChange.Margin = new System.Windows.Forms.Padding(0);
            this.qqChange.MaxLength = 32767;
            this.qqChange.MinimumSize = new System.Drawing.Size(28, 28);
            this.qqChange.MouseBack = null;
            this.qqChange.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.qqChange.Multiline = false;
            this.qqChange.Name = "qqChange";
            this.qqChange.NormlBack = null;
            this.qqChange.Padding = new System.Windows.Forms.Padding(5);
            this.qqChange.ReadOnly = false;
            this.qqChange.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.qqChange.Size = new System.Drawing.Size(163, 28);
            // 
            // 
            // 
            this.qqChange.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.qqChange.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qqChange.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.qqChange.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.qqChange.SkinTxt.Name = "BaseText";
            this.qqChange.SkinTxt.Size = new System.Drawing.Size(153, 18);
            this.qqChange.SkinTxt.TabIndex = 0;
            this.qqChange.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.qqChange.SkinTxt.WaterText = "";
            this.qqChange.TabIndex = 30;
            this.qqChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.qqChange.Visible = false;
            this.qqChange.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.qqChange.WaterText = "";
            this.qqChange.WordWrap = true;
            // 
            // phoneChange
            // 
            this.phoneChange.BackColor = System.Drawing.Color.Transparent;
            this.phoneChange.DownBack = null;
            this.phoneChange.Icon = null;
            this.phoneChange.IconIsButton = false;
            this.phoneChange.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.phoneChange.IsPasswordChat = '\0';
            this.phoneChange.IsSystemPasswordChar = false;
            this.phoneChange.Lines = new string[0];
            this.phoneChange.Location = new System.Drawing.Point(107, 181);
            this.phoneChange.Margin = new System.Windows.Forms.Padding(0);
            this.phoneChange.MaxLength = 32767;
            this.phoneChange.MinimumSize = new System.Drawing.Size(28, 28);
            this.phoneChange.MouseBack = null;
            this.phoneChange.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.phoneChange.Multiline = false;
            this.phoneChange.Name = "phoneChange";
            this.phoneChange.NormlBack = null;
            this.phoneChange.Padding = new System.Windows.Forms.Padding(5);
            this.phoneChange.ReadOnly = false;
            this.phoneChange.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.phoneChange.Size = new System.Drawing.Size(163, 28);
            // 
            // 
            // 
            this.phoneChange.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phoneChange.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.phoneChange.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.phoneChange.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.phoneChange.SkinTxt.Name = "BaseText";
            this.phoneChange.SkinTxt.Size = new System.Drawing.Size(153, 18);
            this.phoneChange.SkinTxt.TabIndex = 0;
            this.phoneChange.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.phoneChange.SkinTxt.WaterText = "";
            this.phoneChange.TabIndex = 30;
            this.phoneChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phoneChange.Visible = false;
            this.phoneChange.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.phoneChange.WaterText = "";
            this.phoneChange.WordWrap = true;
            // 
            // userNameChange
            // 
            this.userNameChange.BackColor = System.Drawing.Color.Transparent;
            this.userNameChange.DownBack = null;
            this.userNameChange.Icon = null;
            this.userNameChange.IconIsButton = false;
            this.userNameChange.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.userNameChange.IsPasswordChat = '\0';
            this.userNameChange.IsSystemPasswordChar = false;
            this.userNameChange.Lines = new string[0];
            this.userNameChange.Location = new System.Drawing.Point(125, 93);
            this.userNameChange.Margin = new System.Windows.Forms.Padding(0);
            this.userNameChange.MaxLength = 32767;
            this.userNameChange.MinimumSize = new System.Drawing.Size(28, 28);
            this.userNameChange.MouseBack = null;
            this.userNameChange.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.userNameChange.Multiline = false;
            this.userNameChange.Name = "userNameChange";
            this.userNameChange.NormlBack = null;
            this.userNameChange.Padding = new System.Windows.Forms.Padding(5);
            this.userNameChange.ReadOnly = false;
            this.userNameChange.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userNameChange.Size = new System.Drawing.Size(163, 28);
            // 
            // 
            // 
            this.userNameChange.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.userNameChange.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userNameChange.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.userNameChange.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.userNameChange.SkinTxt.Name = "BaseText";
            this.userNameChange.SkinTxt.Size = new System.Drawing.Size(153, 18);
            this.userNameChange.SkinTxt.TabIndex = 0;
            this.userNameChange.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.userNameChange.SkinTxt.WaterText = "";
            this.userNameChange.TabIndex = 29;
            this.userNameChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.userNameChange.Visible = false;
            this.userNameChange.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.userNameChange.WaterText = "";
            this.userNameChange.WordWrap = true;
            // 
            // userInfoCancle
            // 
            this.userInfoCancle.AutoSize = true;
            this.userInfoCancle.Location = new System.Drawing.Point(814, 454);
            this.userInfoCancle.Name = "userInfoCancle";
            this.userInfoCancle.Size = new System.Drawing.Size(32, 17);
            this.userInfoCancle.TabIndex = 28;
            this.userInfoCancle.TabStop = true;
            this.userInfoCancle.Text = "取消";
            this.userInfoCancle.Visible = false;
            this.userInfoCancle.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.userInfoCancle_LinkClicked);
            // 
            // userInfoSure
            // 
            this.userInfoSure.AutoSize = true;
            this.userInfoSure.Location = new System.Drawing.Point(751, 454);
            this.userInfoSure.Name = "userInfoSure";
            this.userInfoSure.Size = new System.Drawing.Size(32, 17);
            this.userInfoSure.TabIndex = 27;
            this.userInfoSure.TabStop = true;
            this.userInfoSure.Text = "确认";
            this.userInfoSure.Visible = false;
            this.userInfoSure.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.userInfoSure_LinkClicked);
            // 
            // uerInformChange
            // 
            this.uerInformChange.AutoSize = true;
            this.uerInformChange.Location = new System.Drawing.Point(751, 231);
            this.uerInformChange.Name = "uerInformChange";
            this.uerInformChange.Size = new System.Drawing.Size(56, 17);
            this.uerInformChange.TabIndex = 26;
            this.uerInformChange.TabStop = true;
            this.uerInformChange.Text = "编辑信息";
            this.uerInformChange.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.uerInformChange_LinkClicked);
            // 
            // personalSign
            // 
            this.personalSign.AutoScroll = true;
            this.personalSign.BackColor = System.Drawing.Color.Transparent;
            this.personalSign.DownBack = null;
            this.personalSign.Icon = null;
            this.personalSign.IconIsButton = false;
            this.personalSign.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.personalSign.IsPasswordChat = '\0';
            this.personalSign.IsSystemPasswordChar = false;
            this.personalSign.Lines = new string[] {
        "个性签名"};
            this.personalSign.Location = new System.Drawing.Point(137, 324);
            this.personalSign.Margin = new System.Windows.Forms.Padding(0);
            this.personalSign.MaxLength = 200;
            this.personalSign.MinimumSize = new System.Drawing.Size(28, 28);
            this.personalSign.MouseBack = null;
            this.personalSign.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.personalSign.Multiline = true;
            this.personalSign.Name = "personalSign";
            this.personalSign.NormlBack = null;
            this.personalSign.Padding = new System.Windows.Forms.Padding(5);
            this.personalSign.ReadOnly = true;
            this.personalSign.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.personalSign.Size = new System.Drawing.Size(709, 114);
            // 
            // 
            // 
            this.personalSign.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.personalSign.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.personalSign.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.personalSign.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.personalSign.SkinTxt.MaxLength = 200;
            this.personalSign.SkinTxt.Multiline = true;
            this.personalSign.SkinTxt.Name = "BaseText";
            this.personalSign.SkinTxt.ReadOnly = true;
            this.personalSign.SkinTxt.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.personalSign.SkinTxt.Size = new System.Drawing.Size(699, 104);
            this.personalSign.SkinTxt.TabIndex = 0;
            this.personalSign.SkinTxt.Text = "个性签名";
            this.personalSign.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.personalSign.SkinTxt.WaterText = "";
            this.personalSign.TabIndex = 25;
            this.personalSign.Text = "个性签名";
            this.personalSign.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.personalSign.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.personalSign.WaterText = "";
            this.personalSign.WordWrap = true;
            // 
            // skinLabel22
            // 
            this.skinLabel22.AutoSize = true;
            this.skinLabel22.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel22.BorderColor = System.Drawing.Color.White;
            this.skinLabel22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel22.ForeColor = System.Drawing.Color.Black;
            this.skinLabel22.Location = new System.Drawing.Point(64, 324);
            this.skinLabel22.Name = "skinLabel22";
            this.skinLabel22.Size = new System.Drawing.Size(68, 17);
            this.skinLabel22.TabIndex = 24;
            this.skinLabel22.Text = "个性签名：";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(751, 184);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(56, 17);
            this.linkLabel1.TabIndex = 23;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "更换头像";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // leveltext
            // 
            this.leveltext.AutoSize = true;
            this.leveltext.BackColor = System.Drawing.Color.Transparent;
            this.leveltext.BorderColor = System.Drawing.Color.Transparent;
            this.leveltext.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.leveltext.ForeColor = System.Drawing.Color.Black;
            this.leveltext.Location = new System.Drawing.Point(151, 275);
            this.leveltext.Name = "leveltext";
            this.leveltext.Size = new System.Drawing.Size(29, 17);
            this.leveltext.TabIndex = 22;
            this.leveltext.Text = "aaa";
            // 
            // skinLabel15
            // 
            this.skinLabel15.AutoSize = true;
            this.skinLabel15.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel15.BorderColor = System.Drawing.Color.White;
            this.skinLabel15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel15.ForeColor = System.Drawing.Color.Black;
            this.skinLabel15.Location = new System.Drawing.Point(64, 275);
            this.skinLabel15.Name = "skinLabel15";
            this.skinLabel15.Size = new System.Drawing.Size(80, 17);
            this.skinLabel15.TabIndex = 21;
            this.skinLabel15.Text = "当前权限为：";
            // 
            // qq
            // 
            this.qq.AutoSize = true;
            this.qq.BackColor = System.Drawing.Color.Transparent;
            this.qq.BorderColor = System.Drawing.Color.Transparent;
            this.qq.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qq.ForeColor = System.Drawing.Color.Black;
            this.qq.Location = new System.Drawing.Point(104, 231);
            this.qq.Name = "qq";
            this.qq.Size = new System.Drawing.Size(29, 17);
            this.qq.TabIndex = 20;
            this.qq.Text = "aaa";
            // 
            // phone
            // 
            this.phone.AutoSize = true;
            this.phone.BackColor = System.Drawing.Color.Transparent;
            this.phone.BorderColor = System.Drawing.Color.Transparent;
            this.phone.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.phone.ForeColor = System.Drawing.Color.Black;
            this.phone.Location = new System.Drawing.Point(117, 185);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(29, 17);
            this.phone.TabIndex = 19;
            this.phone.Text = "aaa";
            // 
            // userid
            // 
            this.userid.AutoSize = true;
            this.userid.BackColor = System.Drawing.Color.Transparent;
            this.userid.BorderColor = System.Drawing.Color.Transparent;
            this.userid.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userid.ForeColor = System.Drawing.Color.Black;
            this.userid.Location = new System.Drawing.Point(117, 142);
            this.userid.Name = "userid";
            this.userid.Size = new System.Drawing.Size(29, 17);
            this.userid.TabIndex = 18;
            this.userid.Text = "aaa";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.BorderColor = System.Drawing.Color.Transparent;
            this.username.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.username.ForeColor = System.Drawing.Color.Black;
            this.username.Location = new System.Drawing.Point(134, 97);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(29, 17);
            this.username.TabIndex = 17;
            this.username.Text = "aaa";
            // 
            // nameshow
            // 
            this.nameshow.AutoSize = true;
            this.nameshow.BackColor = System.Drawing.Color.Transparent;
            this.nameshow.BorderColor = System.Drawing.Color.Transparent;
            this.nameshow.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nameshow.ForeColor = System.Drawing.Color.Black;
            this.nameshow.Location = new System.Drawing.Point(116, 53);
            this.nameshow.Name = "nameshow";
            this.nameshow.Size = new System.Drawing.Size(29, 17);
            this.nameshow.TabIndex = 16;
            this.nameshow.Text = "aaa";
            // 
            // head
            // 
            this.head.BackColor = System.Drawing.Color.Transparent;
            this.head.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.none;
            this.head.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.head.Location = new System.Drawing.Point(723, 34);
            this.head.Name = "head";
            this.head.Size = new System.Drawing.Size(123, 125);
            this.head.TabIndex = 15;
            // 
            // skinLabel14
            // 
            this.skinLabel14.AutoSize = true;
            this.skinLabel14.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel14.BorderColor = System.Drawing.Color.White;
            this.skinLabel14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel14.ForeColor = System.Drawing.Color.Black;
            this.skinLabel14.Location = new System.Drawing.Point(64, 231);
            this.skinLabel14.Name = "skinLabel14";
            this.skinLabel14.Size = new System.Drawing.Size(36, 17);
            this.skinLabel14.TabIndex = 14;
            this.skinLabel14.Text = "qq：";
            // 
            // skinLabel13
            // 
            this.skinLabel13.AutoSize = true;
            this.skinLabel13.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel13.BorderColor = System.Drawing.Color.White;
            this.skinLabel13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel13.ForeColor = System.Drawing.Color.Black;
            this.skinLabel13.Location = new System.Drawing.Point(64, 185);
            this.skinLabel13.Name = "skinLabel13";
            this.skinLabel13.Size = new System.Drawing.Size(44, 17);
            this.skinLabel13.TabIndex = 13;
            this.skinLabel13.Text = "电话：";
            // 
            // skinLabel12
            // 
            this.skinLabel12.AutoSize = true;
            this.skinLabel12.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel12.BorderColor = System.Drawing.Color.White;
            this.skinLabel12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel12.ForeColor = System.Drawing.Color.Black;
            this.skinLabel12.Location = new System.Drawing.Point(64, 142);
            this.skinLabel12.Name = "skinLabel12";
            this.skinLabel12.Size = new System.Drawing.Size(44, 17);
            this.skinLabel12.TabIndex = 12;
            this.skinLabel12.Text = "学号：";
            // 
            // skinLabel11
            // 
            this.skinLabel11.AutoSize = true;
            this.skinLabel11.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel11.BorderColor = System.Drawing.Color.White;
            this.skinLabel11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel11.ForeColor = System.Drawing.Color.Black;
            this.skinLabel11.Location = new System.Drawing.Point(64, 97);
            this.skinLabel11.Name = "skinLabel11";
            this.skinLabel11.Size = new System.Drawing.Size(60, 17);
            this.skinLabel11.TabIndex = 11;
            this.skinLabel11.Text = "用户名 ：";
            // 
            // skinLabel10
            // 
            this.skinLabel10.AutoSize = true;
            this.skinLabel10.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel10.BorderColor = System.Drawing.Color.White;
            this.skinLabel10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel10.ForeColor = System.Drawing.Color.Black;
            this.skinLabel10.Location = new System.Drawing.Point(64, 54);
            this.skinLabel10.Name = "skinLabel10";
            this.skinLabel10.Size = new System.Drawing.Size(44, 17);
            this.skinLabel10.TabIndex = 10;
            this.skinLabel10.Text = "姓名：";
            // 
            // message
            // 
            this.message.BackColor = System.Drawing.Color.White;
            this.message.Controls.Add(this.skinPanel5);
            this.message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.message.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.message.Location = new System.Drawing.Point(0, 36);
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(984, 511);
            this.message.TabIndex = 3;
            this.message.TabItemImage = null;
            this.message.Text = "信息盒子";
            // 
            // skinPanel5
            // 
            this.skinPanel5.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel5.Controls.Add(this.answerRemindPanel);
            this.skinPanel5.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanel5.DownBack = null;
            this.skinPanel5.Location = new System.Drawing.Point(0, 0);
            this.skinPanel5.MouseBack = null;
            this.skinPanel5.Name = "skinPanel5";
            this.skinPanel5.NormlBack = null;
            this.skinPanel5.Size = new System.Drawing.Size(984, 511);
            this.skinPanel5.TabIndex = 2;
            // 
            // answerRemindPanel
            // 
            this.answerRemindPanel.AutoScroll = true;
            this.answerRemindPanel.BackColor = System.Drawing.Color.Transparent;
            this.answerRemindPanel.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.answerRemindPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.answerRemindPanel.DownBack = null;
            this.answerRemindPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.answerRemindPanel.Location = new System.Drawing.Point(0, 0);
            this.answerRemindPanel.MouseBack = null;
            this.answerRemindPanel.Name = "answerRemindPanel";
            this.answerRemindPanel.NormlBack = null;
            this.answerRemindPanel.Size = new System.Drawing.Size(984, 511);
            this.answerRemindPanel.TabIndex = 0;
            this.answerRemindPanel.WrapContents = false;
            // 
            // bookstore
            // 
            this.bookstore.BackColor = System.Drawing.Color.White;
            this.bookstore.Controls.Add(this.skinSplitContainer1);
            this.bookstore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookstore.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookstore.ForeColor = System.Drawing.Color.White;
            this.bookstore.ImageIndex = 0;
            this.bookstore.Location = new System.Drawing.Point(0, 36);
            this.bookstore.Name = "bookstore";
            this.bookstore.Size = new System.Drawing.Size(984, 547);
            this.bookstore.TabIndex = 1;
            this.bookstore.TabItemImage = null;
            this.bookstore.Text = "数字图书馆";
            this.bookstore.UseVisualStyleBackColor = true;
            // 
            // skinSplitContainer1
            // 
            this.skinSplitContainer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer1.Name = "skinSplitContainer1";
            // 
            // skinSplitContainer1.Panel1
            // 
            this.skinSplitContainer1.Panel1.Controls.Add(this.booklist);
            this.skinSplitContainer1.Panel1.Controls.Add(this.skinPanel1);
            this.skinSplitContainer1.Panel1.Controls.Add(this.skinTreeView1);
            // 
            // skinSplitContainer1.Panel2
            // 
            this.skinSplitContainer1.Panel2.AutoScroll = true;
            this.skinSplitContainer1.Panel2.Controls.Add(this.skinPanel6);
            this.skinSplitContainer1.Size = new System.Drawing.Size(984, 547);
            this.skinSplitContainer1.SplitterDistance = 406;
            this.skinSplitContainer1.TabIndex = 0;
            // 
            // booklist
            // 
            this.booklist.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.booklist.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.booklist.AutoGenerateColumns = false;
            this.booklist.BackgroundColor = System.Drawing.SystemColors.Window;
            this.booklist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.booklist.ColumnFont = null;
            this.booklist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.booklist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.booklist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.booklist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.autorDataGridViewTextBoxColumn,
            this.pubnameDataGridViewTextBoxColumn});
            this.booklist.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.booklist.DataSource = this.tbbookBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.booklist.DefaultCellStyle = dataGridViewCellStyle3;
            this.booklist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.booklist.EnableHeadersVisualStyles = false;
            this.booklist.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.booklist.HeadFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.booklist.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.booklist.Location = new System.Drawing.Point(0, 40);
            this.booklist.Name = "booklist";
            this.booklist.ReadOnly = true;
            this.booklist.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.booklist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.booklist.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.booklist.RowTemplate.Height = 23;
            this.booklist.Size = new System.Drawing.Size(406, 507);
            this.booklist.TabIndex = 3;
            this.booklist.TitleBack = null;
            this.booklist.TitleBackColorBegin = System.Drawing.Color.White;
            this.booklist.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            this.booklist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.booklist_CellDoubleClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "书名";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "类型";
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            this.typeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // autorDataGridViewTextBoxColumn
            // 
            this.autorDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.autorDataGridViewTextBoxColumn.DataPropertyName = "autor";
            this.autorDataGridViewTextBoxColumn.HeaderText = "作者";
            this.autorDataGridViewTextBoxColumn.Name = "autorDataGridViewTextBoxColumn";
            this.autorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pubnameDataGridViewTextBoxColumn
            // 
            this.pubnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.pubnameDataGridViewTextBoxColumn.DataPropertyName = "pubname";
            this.pubnameDataGridViewTextBoxColumn.HeaderText = "出版社";
            this.pubnameDataGridViewTextBoxColumn.Name = "pubnameDataGridViewTextBoxColumn";
            this.pubnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tbbookBindingSource
            // 
            this.tbbookBindingSource.DataMember = "tb_book";
            this.tbbookBindingSource.DataSource = this.db_libaryDataSet;
            // 
            // db_libaryDataSet
            // 
            this.db_libaryDataSet.DataSetName = "db_libaryDataSet";
            this.db_libaryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // skinPanel1
            // 
            this.skinPanel1.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel1.Controls.Add(this.skinButton3);
            this.skinPanel1.Controls.Add(this.booktype);
            this.skinPanel1.Controls.Add(this.booklistsearch);
            this.skinPanel1.Controls.Add(this.booksearch);
            this.skinPanel1.Controls.Add(this.skinLabel9);
            this.skinPanel1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinPanel1.DownBack = null;
            this.skinPanel1.Location = new System.Drawing.Point(0, 0);
            this.skinPanel1.MouseBack = null;
            this.skinPanel1.Name = "skinPanel1";
            this.skinPanel1.NormlBack = null;
            this.skinPanel1.Size = new System.Drawing.Size(406, 40);
            this.skinPanel1.TabIndex = 2;
            // 
            // skinButton3
            // 
            this.skinButton3.BackColor = System.Drawing.Color.Transparent;
            this.skinButton3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton3.DownBack = null;
            this.skinButton3.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton3.Location = new System.Drawing.Point(3, 6);
            this.skinButton3.MouseBack = null;
            this.skinButton3.Name = "skinButton3";
            this.skinButton3.NormlBack = global::LibraryUI_rebuild.Properties.Resources.reload_white;
            this.skinButton3.Size = new System.Drawing.Size(32, 28);
            this.skinButton3.TabIndex = 4;
            this.skinButton3.UseVisualStyleBackColor = false;
            this.skinButton3.Click += new System.EventHandler(this.skinButton3_Click);
            // 
            // booktype
            // 
            this.booktype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.booktype.FormattingEnabled = true;
            this.booktype.Items.AddRange(new object[] {
            "书名",
            "类型",
            "出版社",
            "作者"});
            this.booktype.Location = new System.Drawing.Point(94, 8);
            this.booktype.Name = "booktype";
            this.booktype.Size = new System.Drawing.Size(88, 24);
            this.booktype.TabIndex = 3;
            this.booktype.WaterText = "";
            // 
            // booklistsearch
            // 
            this.booklistsearch.BackColor = System.Drawing.Color.Transparent;
            this.booklistsearch.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.booklistsearch.DownBack = global::LibraryUI_rebuild.Properties.Resources.search;
            this.booklistsearch.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.booklistsearch.Location = new System.Drawing.Point(367, 6);
            this.booklistsearch.MouseBack = global::LibraryUI_rebuild.Properties.Resources.search;
            this.booklistsearch.Name = "booklistsearch";
            this.booklistsearch.NormlBack = global::LibraryUI_rebuild.Properties.Resources.search_gray;
            this.booklistsearch.Size = new System.Drawing.Size(32, 28);
            this.booklistsearch.TabIndex = 1;
            this.booklistsearch.UseVisualStyleBackColor = false;
            this.booklistsearch.Click += new System.EventHandler(this.booklistsearch_Click);
            // 
            // booksearch
            // 
            this.booksearch.BackColor = System.Drawing.Color.Transparent;
            this.booksearch.DownBack = null;
            this.booksearch.Icon = null;
            this.booksearch.IconIsButton = false;
            this.booksearch.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.booksearch.IsPasswordChat = '\0';
            this.booksearch.IsSystemPasswordChar = false;
            this.booksearch.Lines = new string[0];
            this.booksearch.Location = new System.Drawing.Point(185, 6);
            this.booksearch.Margin = new System.Windows.Forms.Padding(0);
            this.booksearch.MaxLength = 32767;
            this.booksearch.MinimumSize = new System.Drawing.Size(28, 28);
            this.booksearch.MouseBack = null;
            this.booksearch.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.booksearch.Multiline = false;
            this.booksearch.Name = "booksearch";
            this.booksearch.NormlBack = null;
            this.booksearch.Padding = new System.Windows.Forms.Padding(5);
            this.booksearch.ReadOnly = false;
            this.booksearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.booksearch.Size = new System.Drawing.Size(179, 28);
            // 
            // 
            // 
            this.booksearch.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.booksearch.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.booksearch.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.booksearch.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.booksearch.SkinTxt.Name = "BaseText";
            this.booksearch.SkinTxt.Size = new System.Drawing.Size(169, 18);
            this.booksearch.SkinTxt.TabIndex = 0;
            this.booksearch.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.booksearch.SkinTxt.WaterText = "输入关键字";
            this.booksearch.TabIndex = 2;
            this.booksearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.booksearch.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.booksearch.WaterText = "输入关键字";
            this.booksearch.WordWrap = true;
            // 
            // skinLabel9
            // 
            this.skinLabel9.AutoSize = true;
            this.skinLabel9.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel9.BorderColor = System.Drawing.Color.White;
            this.skinLabel9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel9.ForeColor = System.Drawing.Color.Black;
            this.skinLabel9.Location = new System.Drawing.Point(56, 12);
            this.skinLabel9.Name = "skinLabel9";
            this.skinLabel9.Size = new System.Drawing.Size(32, 17);
            this.skinLabel9.TabIndex = 1;
            this.skinLabel9.Text = "搜索";
            // 
            // skinTreeView1
            // 
            this.skinTreeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTreeView1.Location = new System.Drawing.Point(0, 0);
            this.skinTreeView1.Name = "skinTreeView1";
            this.skinTreeView1.Size = new System.Drawing.Size(406, 547);
            this.skinTreeView1.TabIndex = 0;
            // 
            // skinPanel6
            // 
            this.skinPanel6.AutoScroll = true;
            this.skinPanel6.AutoScrollMargin = new System.Drawing.Size(0, 20);
            this.skinPanel6.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel6.Controls.Add(this.skinPanel2);
            this.skinPanel6.Controls.Add(this.commentList);
            this.skinPanel6.Controls.Add(this.bookPicture);
            this.skinPanel6.Controls.Add(this.bookdate);
            this.skinPanel6.Controls.Add(this.bookprice);
            this.skinPanel6.Controls.Add(this.bookpage);
            this.skinPanel6.Controls.Add(this.skinLabel24);
            this.skinPanel6.Controls.Add(this.skinLabel7);
            this.skinPanel6.Controls.Add(this.skinLabel23);
            this.skinPanel6.Controls.Add(this.booksorted);
            this.skinPanel6.Controls.Add(this.bookPubname);
            this.skinPanel6.Controls.Add(this.bookauthor);
            this.skinPanel6.Controls.Add(this.bookName);
            this.skinPanel6.Controls.Add(this.skinLabel21);
            this.skinPanel6.Controls.Add(this.skinLabel20);
            this.skinPanel6.Controls.Add(this.bookIntro);
            this.skinPanel6.Controls.Add(this.skinLabel19);
            this.skinPanel6.Controls.Add(this.skinLabel18);
            this.skinPanel6.Controls.Add(this.skinLabel17);
            this.skinPanel6.Controls.Add(this.skinLabel16);
            this.skinPanel6.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanel6.DownBack = null;
            this.skinPanel6.Location = new System.Drawing.Point(0, 0);
            this.skinPanel6.MouseBack = null;
            this.skinPanel6.Name = "skinPanel6";
            this.skinPanel6.NormlBack = null;
            this.skinPanel6.Size = new System.Drawing.Size(574, 547);
            this.skinPanel6.TabIndex = 0;
            // 
            // skinPanel2
            // 
            this.skinPanel2.AutoSize = true;
            this.skinPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.skinPanel2.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel2.Controls.Add(this.skinPanel7);
            this.skinPanel2.Controls.Add(this.skinToolStrip3);
            this.skinPanel2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.skinPanel2.DownBack = null;
            this.skinPanel2.Location = new System.Drawing.Point(0, 1043);
            this.skinPanel2.MouseBack = null;
            this.skinPanel2.Name = "skinPanel2";
            this.skinPanel2.NormlBack = null;
            this.skinPanel2.Size = new System.Drawing.Size(557, 93);
            this.skinPanel2.TabIndex = 60;
            // 
            // skinPanel7
            // 
            this.skinPanel7.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel7.Controls.Add(this.commentUpload);
            this.skinPanel7.Controls.Add(this.commentText);
            this.skinPanel7.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinPanel7.DownBack = null;
            this.skinPanel7.Location = new System.Drawing.Point(0, 25);
            this.skinPanel7.MouseBack = null;
            this.skinPanel7.Name = "skinPanel7";
            this.skinPanel7.NormlBack = null;
            this.skinPanel7.Size = new System.Drawing.Size(557, 68);
            this.skinPanel7.TabIndex = 1;
            // 
            // commentUpload
            // 
            this.commentUpload.BackColor = System.Drawing.Color.Transparent;
            this.commentUpload.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.commentUpload.Dock = System.Windows.Forms.DockStyle.Right;
            this.commentUpload.DownBack = null;
            this.commentUpload.Location = new System.Drawing.Point(496, 0);
            this.commentUpload.Margin = new System.Windows.Forms.Padding(0);
            this.commentUpload.MouseBack = null;
            this.commentUpload.Name = "commentUpload";
            this.commentUpload.NormlBack = null;
            this.commentUpload.Size = new System.Drawing.Size(61, 68);
            this.commentUpload.TabIndex = 1;
            this.commentUpload.Text = "发送评论";
            this.commentUpload.UseVisualStyleBackColor = false;
            this.commentUpload.Click += new System.EventHandler(this.commentUpload_Click);
            // 
            // commentText
            // 
            this.commentText.BackColor = System.Drawing.Color.Transparent;
            this.commentText.Dock = System.Windows.Forms.DockStyle.Left;
            this.commentText.DownBack = null;
            this.commentText.Icon = null;
            this.commentText.IconIsButton = false;
            this.commentText.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.commentText.IsPasswordChat = '\0';
            this.commentText.IsSystemPasswordChar = false;
            this.commentText.Lines = new string[0];
            this.commentText.Location = new System.Drawing.Point(0, 0);
            this.commentText.Margin = new System.Windows.Forms.Padding(0);
            this.commentText.MaxLength = 500;
            this.commentText.MinimumSize = new System.Drawing.Size(28, 28);
            this.commentText.MouseBack = null;
            this.commentText.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.commentText.Multiline = true;
            this.commentText.Name = "commentText";
            this.commentText.NormlBack = null;
            this.commentText.Padding = new System.Windows.Forms.Padding(5);
            this.commentText.ReadOnly = false;
            this.commentText.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.commentText.Size = new System.Drawing.Size(496, 68);
            // 
            // 
            // 
            this.commentText.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.commentText.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.commentText.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.commentText.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.commentText.SkinTxt.MaxLength = 500;
            this.commentText.SkinTxt.Multiline = true;
            this.commentText.SkinTxt.Name = "BaseText";
            this.commentText.SkinTxt.Size = new System.Drawing.Size(486, 58);
            this.commentText.SkinTxt.TabIndex = 0;
            this.commentText.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.commentText.SkinTxt.WaterText = "";
            this.commentText.TabIndex = 0;
            this.commentText.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.commentText.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.commentText.WaterText = "";
            this.commentText.WordWrap = true;
            // 
            // skinToolStrip3
            // 
            this.skinToolStrip3.Arrow = System.Drawing.Color.Black;
            this.skinToolStrip3.Back = System.Drawing.Color.White;
            this.skinToolStrip3.BackRadius = 4;
            this.skinToolStrip3.BackRectangle = new System.Drawing.Rectangle(10, 10, 10, 10);
            this.skinToolStrip3.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.skinToolStrip3.BaseFore = System.Drawing.Color.Black;
            this.skinToolStrip3.BaseForeAnamorphosis = false;
            this.skinToolStrip3.BaseForeAnamorphosisBorder = 4;
            this.skinToolStrip3.BaseForeAnamorphosisColor = System.Drawing.Color.White;
            this.skinToolStrip3.BaseForeOffset = new System.Drawing.Point(0, 0);
            this.skinToolStrip3.BaseHoverFore = System.Drawing.Color.White;
            this.skinToolStrip3.BaseItemAnamorphosis = true;
            this.skinToolStrip3.BaseItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.BaseItemBorderShow = true;
            this.skinToolStrip3.BaseItemDown = ((System.Drawing.Image)(resources.GetObject("skinToolStrip3.BaseItemDown")));
            this.skinToolStrip3.BaseItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.BaseItemMouse = ((System.Drawing.Image)(resources.GetObject("skinToolStrip3.BaseItemMouse")));
            this.skinToolStrip3.BaseItemNorml = null;
            this.skinToolStrip3.BaseItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.BaseItemRadius = 4;
            this.skinToolStrip3.BaseItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip3.BaseItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.BindTabControl = null;
            this.skinToolStrip3.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.skinToolStrip3.Fore = System.Drawing.Color.Black;
            this.skinToolStrip3.GripMargin = new System.Windows.Forms.Padding(2, 2, 4, 2);
            this.skinToolStrip3.HoverFore = System.Drawing.Color.White;
            this.skinToolStrip3.ItemAnamorphosis = true;
            this.skinToolStrip3.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.ItemBorderShow = true;
            this.skinToolStrip3.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip3.ItemRadius = 4;
            this.skinToolStrip3.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton2});
            this.skinToolStrip3.Location = new System.Drawing.Point(0, 0);
            this.skinToolStrip3.Name = "skinToolStrip3";
            this.skinToolStrip3.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip3.Size = new System.Drawing.Size(557, 25);
            this.skinToolStrip3.SkinAllColor = true;
            this.skinToolStrip3.TabIndex = 0;
            this.skinToolStrip3.Text = "skinToolStrip3";
            this.skinToolStrip3.TitleAnamorphosis = true;
            this.skinToolStrip3.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.skinToolStrip3.TitleRadius = 4;
            this.skinToolStrip3.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // commentList
            // 
            this.commentList.AutoScroll = true;
            this.commentList.BackColor = System.Drawing.Color.Transparent;
            this.commentList.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.commentList.DownBack = null;
            this.commentList.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.commentList.Location = new System.Drawing.Point(28, 510);
            this.commentList.MouseBack = null;
            this.commentList.Name = "commentList";
            this.commentList.NormlBack = null;
            this.commentList.Size = new System.Drawing.Size(505, 513);
            this.commentList.TabIndex = 59;
            this.commentList.WrapContents = false;
            // 
            // bookPicture
            // 
            this.bookPicture.BackColor = System.Drawing.Color.Transparent;
            this.bookPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookPicture.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.bookPicture.DownBack = null;
            this.bookPicture.Location = new System.Drawing.Point(393, 24);
            this.bookPicture.MouseBack = null;
            this.bookPicture.Name = "bookPicture";
            this.bookPicture.NormlBack = null;
            this.bookPicture.Size = new System.Drawing.Size(140, 140);
            this.bookPicture.TabIndex = 58;
            // 
            // bookdate
            // 
            this.bookdate.AutoSize = true;
            this.bookdate.BackColor = System.Drawing.Color.Transparent;
            this.bookdate.BorderColor = System.Drawing.Color.White;
            this.bookdate.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookdate.ForeColor = System.Drawing.Color.Black;
            this.bookdate.Location = new System.Drawing.Point(220, 201);
            this.bookdate.Name = "bookdate";
            this.bookdate.Size = new System.Drawing.Size(0, 17);
            this.bookdate.TabIndex = 57;
            // 
            // bookprice
            // 
            this.bookprice.AutoSize = true;
            this.bookprice.BackColor = System.Drawing.Color.Transparent;
            this.bookprice.BorderColor = System.Drawing.Color.White;
            this.bookprice.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookprice.ForeColor = System.Drawing.Color.Black;
            this.bookprice.Location = new System.Drawing.Point(71, 201);
            this.bookprice.Name = "bookprice";
            this.bookprice.Size = new System.Drawing.Size(0, 17);
            this.bookprice.TabIndex = 56;
            // 
            // bookpage
            // 
            this.bookpage.AutoSize = true;
            this.bookpage.BackColor = System.Drawing.Color.Transparent;
            this.bookpage.BorderColor = System.Drawing.Color.White;
            this.bookpage.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookpage.ForeColor = System.Drawing.Color.Black;
            this.bookpage.Location = new System.Drawing.Point(84, 168);
            this.bookpage.Name = "bookpage";
            this.bookpage.Size = new System.Drawing.Size(0, 17);
            this.bookpage.TabIndex = 55;
            // 
            // skinLabel24
            // 
            this.skinLabel24.AutoSize = true;
            this.skinLabel24.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel24.BorderColor = System.Drawing.Color.White;
            this.skinLabel24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel24.ForeColor = System.Drawing.Color.Black;
            this.skinLabel24.Location = new System.Drawing.Point(155, 201);
            this.skinLabel24.Name = "skinLabel24";
            this.skinLabel24.Size = new System.Drawing.Size(68, 17);
            this.skinLabel24.TabIndex = 54;
            this.skinLabel24.Text = "出版时间：";
            // 
            // skinLabel7
            // 
            this.skinLabel7.AutoSize = true;
            this.skinLabel7.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel7.BorderColor = System.Drawing.Color.White;
            this.skinLabel7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel7.ForeColor = System.Drawing.Color.Black;
            this.skinLabel7.Location = new System.Drawing.Point(21, 201);
            this.skinLabel7.Name = "skinLabel7";
            this.skinLabel7.Size = new System.Drawing.Size(44, 17);
            this.skinLabel7.TabIndex = 53;
            this.skinLabel7.Text = "定价：";
            // 
            // skinLabel23
            // 
            this.skinLabel23.AutoSize = true;
            this.skinLabel23.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel23.BorderColor = System.Drawing.Color.White;
            this.skinLabel23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel23.ForeColor = System.Drawing.Color.Black;
            this.skinLabel23.Location = new System.Drawing.Point(22, 168);
            this.skinLabel23.Name = "skinLabel23";
            this.skinLabel23.Size = new System.Drawing.Size(56, 17);
            this.skinLabel23.TabIndex = 52;
            this.skinLabel23.Text = "页码数：";
            // 
            // booksorted
            // 
            this.booksorted.AutoSize = true;
            this.booksorted.BackColor = System.Drawing.Color.Transparent;
            this.booksorted.BorderColor = System.Drawing.Color.White;
            this.booksorted.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.booksorted.ForeColor = System.Drawing.Color.Black;
            this.booksorted.Location = new System.Drawing.Point(63, 132);
            this.booksorted.Name = "booksorted";
            this.booksorted.Size = new System.Drawing.Size(0, 17);
            this.booksorted.TabIndex = 12;
            // 
            // bookPubname
            // 
            this.bookPubname.AutoSize = true;
            this.bookPubname.BackColor = System.Drawing.Color.Transparent;
            this.bookPubname.BorderColor = System.Drawing.Color.White;
            this.bookPubname.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookPubname.ForeColor = System.Drawing.Color.Black;
            this.bookPubname.Location = new System.Drawing.Point(75, 95);
            this.bookPubname.Name = "bookPubname";
            this.bookPubname.Size = new System.Drawing.Size(0, 17);
            this.bookPubname.TabIndex = 11;
            // 
            // bookauthor
            // 
            this.bookauthor.AutoSize = true;
            this.bookauthor.BackColor = System.Drawing.Color.Transparent;
            this.bookauthor.BorderColor = System.Drawing.Color.White;
            this.bookauthor.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookauthor.ForeColor = System.Drawing.Color.Black;
            this.bookauthor.Location = new System.Drawing.Point(63, 57);
            this.bookauthor.Name = "bookauthor";
            this.bookauthor.Size = new System.Drawing.Size(0, 17);
            this.bookauthor.TabIndex = 10;
            // 
            // bookName
            // 
            this.bookName.AutoSize = true;
            this.bookName.BackColor = System.Drawing.Color.Transparent;
            this.bookName.BorderColor = System.Drawing.Color.White;
            this.bookName.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookName.ForeColor = System.Drawing.Color.Black;
            this.bookName.Location = new System.Drawing.Point(63, 23);
            this.bookName.Name = "bookName";
            this.bookName.Size = new System.Drawing.Size(0, 17);
            this.bookName.TabIndex = 9;
            // 
            // skinLabel21
            // 
            this.skinLabel21.AutoSize = true;
            this.skinLabel21.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel21.BorderColor = System.Drawing.Color.White;
            this.skinLabel21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel21.ForeColor = System.Drawing.Color.Black;
            this.skinLabel21.Location = new System.Drawing.Point(22, 482);
            this.skinLabel21.Name = "skinLabel21";
            this.skinLabel21.Size = new System.Drawing.Size(44, 17);
            this.skinLabel21.TabIndex = 7;
            this.skinLabel21.Text = "书评：";
            // 
            // skinLabel20
            // 
            this.skinLabel20.AutoSize = true;
            this.skinLabel20.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel20.BorderColor = System.Drawing.Color.White;
            this.skinLabel20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel20.ForeColor = System.Drawing.Color.Black;
            this.skinLabel20.Location = new System.Drawing.Point(22, 246);
            this.skinLabel20.Name = "skinLabel20";
            this.skinLabel20.Size = new System.Drawing.Size(44, 17);
            this.skinLabel20.TabIndex = 6;
            this.skinLabel20.Text = "简介：";
            // 
            // bookIntro
            // 
            this.bookIntro.AutoScroll = true;
            this.bookIntro.BackColor = System.Drawing.Color.Transparent;
            this.bookIntro.DownBack = null;
            this.bookIntro.Icon = null;
            this.bookIntro.IconIsButton = false;
            this.bookIntro.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIntro.IsPasswordChat = '\0';
            this.bookIntro.IsSystemPasswordChar = false;
            this.bookIntro.Lines = new string[] {
        "简介"};
            this.bookIntro.Location = new System.Drawing.Point(25, 274);
            this.bookIntro.Margin = new System.Windows.Forms.Padding(0);
            this.bookIntro.MaxLength = 32767;
            this.bookIntro.MinimumSize = new System.Drawing.Size(28, 28);
            this.bookIntro.MouseBack = null;
            this.bookIntro.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookIntro.Multiline = true;
            this.bookIntro.Name = "bookIntro";
            this.bookIntro.NormlBack = null;
            this.bookIntro.Padding = new System.Windows.Forms.Padding(5);
            this.bookIntro.ReadOnly = true;
            this.bookIntro.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.bookIntro.Size = new System.Drawing.Size(508, 182);
            // 
            // 
            // 
            this.bookIntro.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bookIntro.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookIntro.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookIntro.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.bookIntro.SkinTxt.Multiline = true;
            this.bookIntro.SkinTxt.Name = "BaseText";
            this.bookIntro.SkinTxt.ReadOnly = true;
            this.bookIntro.SkinTxt.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.bookIntro.SkinTxt.Size = new System.Drawing.Size(498, 172);
            this.bookIntro.SkinTxt.TabIndex = 0;
            this.bookIntro.SkinTxt.Text = "简介";
            this.bookIntro.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIntro.SkinTxt.WaterText = "";
            this.bookIntro.TabIndex = 5;
            this.bookIntro.Text = "简介";
            this.bookIntro.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bookIntro.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookIntro.WaterText = "";
            this.bookIntro.WordWrap = true;
            // 
            // skinLabel19
            // 
            this.skinLabel19.AutoSize = true;
            this.skinLabel19.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel19.BorderColor = System.Drawing.Color.White;
            this.skinLabel19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel19.ForeColor = System.Drawing.Color.Black;
            this.skinLabel19.Location = new System.Drawing.Point(22, 132);
            this.skinLabel19.Name = "skinLabel19";
            this.skinLabel19.Size = new System.Drawing.Size(44, 17);
            this.skinLabel19.TabIndex = 3;
            this.skinLabel19.Text = "分类：";
            // 
            // skinLabel18
            // 
            this.skinLabel18.AutoSize = true;
            this.skinLabel18.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel18.BorderColor = System.Drawing.Color.White;
            this.skinLabel18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel18.ForeColor = System.Drawing.Color.Black;
            this.skinLabel18.Location = new System.Drawing.Point(22, 95);
            this.skinLabel18.Name = "skinLabel18";
            this.skinLabel18.Size = new System.Drawing.Size(56, 17);
            this.skinLabel18.TabIndex = 2;
            this.skinLabel18.Text = "出版社：";
            // 
            // skinLabel17
            // 
            this.skinLabel17.AutoSize = true;
            this.skinLabel17.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel17.BorderColor = System.Drawing.Color.White;
            this.skinLabel17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel17.ForeColor = System.Drawing.Color.Black;
            this.skinLabel17.Location = new System.Drawing.Point(22, 57);
            this.skinLabel17.Name = "skinLabel17";
            this.skinLabel17.Size = new System.Drawing.Size(44, 17);
            this.skinLabel17.TabIndex = 1;
            this.skinLabel17.Text = "作者：";
            // 
            // skinLabel16
            // 
            this.skinLabel16.AutoSize = true;
            this.skinLabel16.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel16.BorderColor = System.Drawing.Color.White;
            this.skinLabel16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel16.ForeColor = System.Drawing.Color.Black;
            this.skinLabel16.Location = new System.Drawing.Point(22, 24);
            this.skinLabel16.Name = "skinLabel16";
            this.skinLabel16.Size = new System.Drawing.Size(44, 17);
            this.skinLabel16.TabIndex = 0;
            this.skinLabel16.Text = "书名：";
            // 
            // project
            // 
            this.project.BackColor = System.Drawing.Color.White;
            this.project.Controls.Add(this.skinSplitContainer2);
            this.project.Controls.Add(this.skinPanel10);
            this.project.Dock = System.Windows.Forms.DockStyle.Fill;
            this.project.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.project.ForeColor = System.Drawing.Color.White;
            this.project.ImageIndex = 1;
            this.project.Location = new System.Drawing.Point(0, 36);
            this.project.Name = "project";
            this.project.Size = new System.Drawing.Size(984, 547);
            this.project.TabIndex = 2;
            this.project.TabItemImage = null;
            this.project.Text = "项目发布";
            // 
            // skinSplitContainer2
            // 
            this.skinSplitContainer2.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer2.Name = "skinSplitContainer2";
            // 
            // skinSplitContainer2.Panel1
            // 
            this.skinSplitContainer2.Panel1.Controls.Add(this.ask_Content);
            this.skinSplitContainer2.Panel1.Controls.Add(this.skinPanel12);
            // 
            // skinSplitContainer2.Panel2
            // 
            this.skinSplitContainer2.Panel2.Controls.Add(this.answer_Content);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinPanel11);
            this.skinSplitContainer2.Size = new System.Drawing.Size(984, 377);
            this.skinSplitContainer2.SplitterDistance = 482;
            this.skinSplitContainer2.TabIndex = 10;
            // 
            // ask_Content
            // 
            this.ask_Content.AutoScroll = true;
            this.ask_Content.BackColor = System.Drawing.Color.Transparent;
            this.ask_Content.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.ask_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ask_Content.DownBack = null;
            this.ask_Content.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.ask_Content.Location = new System.Drawing.Point(0, 33);
            this.ask_Content.MouseBack = null;
            this.ask_Content.Name = "ask_Content";
            this.ask_Content.NormlBack = null;
            this.ask_Content.Size = new System.Drawing.Size(482, 344);
            this.ask_Content.TabIndex = 2;
            this.ask_Content.WrapContents = false;
            // 
            // skinPanel12
            // 
            this.skinPanel12.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel12.Controls.Add(this.skinLabel5);
            this.skinPanel12.Controls.Add(this.questionlistType);
            this.skinPanel12.Controls.Add(this.skinButton1);
            this.skinPanel12.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinPanel12.DownBack = null;
            this.skinPanel12.Location = new System.Drawing.Point(0, 0);
            this.skinPanel12.MouseBack = null;
            this.skinPanel12.Name = "skinPanel12";
            this.skinPanel12.NormlBack = null;
            this.skinPanel12.Size = new System.Drawing.Size(482, 33);
            this.skinPanel12.TabIndex = 1;
            // 
            // skinLabel5
            // 
            this.skinLabel5.AutoSize = true;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.ForeColor = System.Drawing.Color.Black;
            this.skinLabel5.Location = new System.Drawing.Point(326, 8);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(32, 17);
            this.skinLabel5.TabIndex = 8;
            this.skinLabel5.Text = "搜索";
            // 
            // questionlistType
            // 
            this.questionlistType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.questionlistType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.questionlistType.FormattingEnabled = true;
            this.questionlistType.Items.AddRange(new object[] {
            "C#",
            "C++",
            "java",
            "php",
            "Html"});
            this.questionlistType.Location = new System.Drawing.Point(359, 5);
            this.questionlistType.Name = "questionlistType";
            this.questionlistType.Size = new System.Drawing.Size(85, 24);
            this.questionlistType.TabIndex = 9;
            this.questionlistType.WaterText = "选择类型";
            // 
            // skinButton1
            // 
            this.skinButton1.BackColor = System.Drawing.Color.Transparent;
            this.skinButton1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton1.DownBack = null;
            this.skinButton1.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.skinButton1.Location = new System.Drawing.Point(450, 2);
            this.skinButton1.MouseBack = null;
            this.skinButton1.Name = "skinButton1";
            this.skinButton1.NormlBack = global::LibraryUI_rebuild.Properties.Resources.search_gray1;
            this.skinButton1.Size = new System.Drawing.Size(28, 28);
            this.skinButton1.TabIndex = 7;
            this.skinButton1.UseVisualStyleBackColor = false;
            this.skinButton1.Click += new System.EventHandler(this.skinButton1_Click);
            // 
            // answer_Content
            // 
            this.answer_Content.AutoScroll = true;
            this.answer_Content.BackColor = System.Drawing.Color.Transparent;
            this.answer_Content.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.answer_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.answer_Content.DownBack = null;
            this.answer_Content.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.answer_Content.Location = new System.Drawing.Point(0, 116);
            this.answer_Content.MouseBack = null;
            this.answer_Content.Name = "answer_Content";
            this.answer_Content.NormlBack = null;
            this.answer_Content.Size = new System.Drawing.Size(498, 261);
            this.answer_Content.TabIndex = 1;
            this.answer_Content.WrapContents = false;
            // 
            // skinPanel11
            // 
            this.skinPanel11.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel11.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.afgxvxsdgfgf;
            this.skinPanel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.skinPanel11.Controls.Add(this.Typeword);
            this.skinPanel11.Controls.Add(this.fileName);
            this.skinPanel11.Controls.Add(this.linkLabel2);
            this.skinPanel11.Controls.Add(this.questionerImg);
            this.skinPanel11.Controls.Add(this.contentword);
            this.skinPanel11.Controls.Add(this.questiondate);
            this.skinPanel11.Controls.Add(this.questioner);
            this.skinPanel11.Controls.Add(this.contenttitle);
            this.skinPanel11.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinPanel11.DownBack = null;
            this.skinPanel11.Location = new System.Drawing.Point(0, 0);
            this.skinPanel11.MouseBack = null;
            this.skinPanel11.Name = "skinPanel11";
            this.skinPanel11.NormlBack = null;
            this.skinPanel11.Size = new System.Drawing.Size(498, 116);
            this.skinPanel11.TabIndex = 0;
            // 
            // Typeword
            // 
            this.Typeword.AutoSize = true;
            this.Typeword.BackColor = System.Drawing.Color.Transparent;
            this.Typeword.BorderColor = System.Drawing.Color.White;
            this.Typeword.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Typeword.ForeColor = System.Drawing.Color.Blue;
            this.Typeword.Location = new System.Drawing.Point(89, 11);
            this.Typeword.Name = "Typeword";
            this.Typeword.Size = new System.Drawing.Size(42, 22);
            this.Typeword.TabIndex = 8;
            this.Typeword.Text = "标题";
            // 
            // fileName
            // 
            this.fileName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.fileName.AutoSize = true;
            this.fileName.BackColor = System.Drawing.Color.Transparent;
            this.fileName.BorderColor = System.Drawing.Color.White;
            this.fileName.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fileName.ForeColor = System.Drawing.Color.Black;
            this.fileName.Location = new System.Drawing.Point(141, 92);
            this.fileName.Name = "fileName";
            this.fileName.Size = new System.Drawing.Size(44, 17);
            this.fileName.TabIndex = 6;
            this.fileName.Text = "文件名";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(97, 92);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(32, 17);
            this.linkLabel2.TabIndex = 7;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "下载";
            this.linkLabel2.Visible = false;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // questionerImg
            // 
            this.questionerImg.BackColor = System.Drawing.Color.Transparent;
            this.questionerImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.questionerImg.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.questionerImg.DownBack = null;
            this.questionerImg.Location = new System.Drawing.Point(13, 36);
            this.questionerImg.MouseBack = null;
            this.questionerImg.Name = "questionerImg";
            this.questionerImg.NormlBack = null;
            this.questionerImg.Size = new System.Drawing.Size(70, 70);
            this.questionerImg.TabIndex = 5;
            // 
            // contentword
            // 
            this.contentword.AutoSize = true;
            this.contentword.BackColor = System.Drawing.Color.Transparent;
            this.contentword.BorderColor = System.Drawing.Color.White;
            this.contentword.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.contentword.ForeColor = System.Drawing.Color.Black;
            this.contentword.Location = new System.Drawing.Point(90, 46);
            this.contentword.Name = "contentword";
            this.contentword.Size = new System.Drawing.Size(32, 17);
            this.contentword.TabIndex = 4;
            this.contentword.Text = "内容";
            // 
            // questiondate
            // 
            this.questiondate.AutoSize = true;
            this.questiondate.BackColor = System.Drawing.Color.Transparent;
            this.questiondate.BorderColor = System.Drawing.Color.White;
            this.questiondate.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.questiondate.ForeColor = System.Drawing.Color.Black;
            this.questiondate.Location = new System.Drawing.Point(331, 92);
            this.questiondate.Name = "questiondate";
            this.questiondate.Size = new System.Drawing.Size(32, 17);
            this.questiondate.TabIndex = 3;
            this.questiondate.Text = "时间";
            // 
            // questioner
            // 
            this.questioner.AutoSize = true;
            this.questioner.BackColor = System.Drawing.Color.Transparent;
            this.questioner.BorderColor = System.Drawing.Color.White;
            this.questioner.Font = new System.Drawing.Font("微软雅黑", 10.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.questioner.ForeColor = System.Drawing.Color.Black;
            this.questioner.Location = new System.Drawing.Point(11, 12);
            this.questioner.Name = "questioner";
            this.questioner.Size = new System.Drawing.Size(51, 19);
            this.questioner.TabIndex = 2;
            this.questioner.Text = "用户名";
            // 
            // contenttitle
            // 
            this.contenttitle.AutoSize = true;
            this.contenttitle.BackColor = System.Drawing.Color.Transparent;
            this.contenttitle.BorderColor = System.Drawing.Color.White;
            this.contenttitle.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.contenttitle.ForeColor = System.Drawing.Color.Black;
            this.contenttitle.Location = new System.Drawing.Point(170, 11);
            this.contenttitle.Name = "contenttitle";
            this.contenttitle.Size = new System.Drawing.Size(42, 22);
            this.contenttitle.TabIndex = 1;
            this.contenttitle.Text = "标题";
            // 
            // skinPanel10
            // 
            this.skinPanel10.AutoSize = true;
            this.skinPanel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.skinPanel10.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel10.Controls.Add(this.skinPanelQuestion);
            this.skinPanel10.Controls.Add(this.skinPanelAnswer);
            this.skinPanel10.Controls.Add(this.skinToolStrip4);
            this.skinPanel10.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.skinPanel10.DownBack = null;
            this.skinPanel10.Location = new System.Drawing.Point(0, 377);
            this.skinPanel10.MouseBack = null;
            this.skinPanel10.Name = "skinPanel10";
            this.skinPanel10.NormlBack = null;
            this.skinPanel10.Size = new System.Drawing.Size(984, 170);
            this.skinPanel10.TabIndex = 9;
            // 
            // skinPanelQuestion
            // 
            this.skinPanelQuestion.BackColor = System.Drawing.Color.Transparent;
            this.skinPanelQuestion.Controls.Add(this.questionUpload);
            this.skinPanelQuestion.Controls.Add(this.questionLoad);
            this.skinPanelQuestion.Controls.Add(this.chooseQusetionFile);
            this.skinPanelQuestion.Controls.Add(this.skinLabel4);
            this.skinPanelQuestion.Controls.Add(this.questionIntro);
            this.skinPanelQuestion.Controls.Add(this.skinLabel3);
            this.skinPanelQuestion.Controls.Add(this.questionType);
            this.skinPanelQuestion.Controls.Add(this.skinLabel2);
            this.skinPanelQuestion.Controls.Add(this.questionTitle);
            this.skinPanelQuestion.Controls.Add(this.skinLabel1);
            this.skinPanelQuestion.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanelQuestion.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.skinPanelQuestion.DownBack = null;
            this.skinPanelQuestion.Location = new System.Drawing.Point(0, 25);
            this.skinPanelQuestion.MouseBack = null;
            this.skinPanelQuestion.Name = "skinPanelQuestion";
            this.skinPanelQuestion.NormlBack = null;
            this.skinPanelQuestion.Size = new System.Drawing.Size(984, 145);
            this.skinPanelQuestion.TabIndex = 1;
            // 
            // questionUpload
            // 
            this.questionUpload.BackColor = System.Drawing.Color.Transparent;
            this.questionUpload.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.questionUpload.DownBack = null;
            this.questionUpload.Location = new System.Drawing.Point(873, 40);
            this.questionUpload.MouseBack = null;
            this.questionUpload.Name = "questionUpload";
            this.questionUpload.NormlBack = null;
            this.questionUpload.Size = new System.Drawing.Size(71, 61);
            this.questionUpload.TabIndex = 17;
            this.questionUpload.Text = "发布问题";
            this.questionUpload.UseVisualStyleBackColor = false;
            this.questionUpload.Click += new System.EventHandler(this.questionUpload_Click);
            // 
            // questionLoad
            // 
            this.questionLoad.AutoSize = true;
            this.questionLoad.BackColor = System.Drawing.Color.Transparent;
            this.questionLoad.BorderColor = System.Drawing.Color.White;
            this.questionLoad.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.questionLoad.ForeColor = System.Drawing.Color.Black;
            this.questionLoad.Location = new System.Drawing.Point(138, 114);
            this.questionLoad.Name = "questionLoad";
            this.questionLoad.Size = new System.Drawing.Size(32, 17);
            this.questionLoad.TabIndex = 16;
            this.questionLoad.Text = "路径";
            // 
            // chooseQusetionFile
            // 
            this.chooseQusetionFile.BackColor = System.Drawing.Color.Transparent;
            this.chooseQusetionFile.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chooseQusetionFile.DownBack = null;
            this.chooseQusetionFile.Location = new System.Drawing.Point(57, 111);
            this.chooseQusetionFile.MouseBack = null;
            this.chooseQusetionFile.Name = "chooseQusetionFile";
            this.chooseQusetionFile.NormlBack = null;
            this.chooseQusetionFile.Size = new System.Drawing.Size(75, 23);
            this.chooseQusetionFile.TabIndex = 15;
            this.chooseQusetionFile.Text = "选择文件";
            this.chooseQusetionFile.UseVisualStyleBackColor = false;
            this.chooseQusetionFile.Click += new System.EventHandler(this.chooseQusetionFile_Click);
            // 
            // skinLabel4
            // 
            this.skinLabel4.AutoSize = true;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.ForeColor = System.Drawing.Color.Black;
            this.skinLabel4.Location = new System.Drawing.Point(19, 114);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(32, 17);
            this.skinLabel4.TabIndex = 14;
            this.skinLabel4.Text = "附件";
            // 
            // questionIntro
            // 
            this.questionIntro.AutoScroll = true;
            this.questionIntro.BackColor = System.Drawing.Color.Transparent;
            this.questionIntro.DownBack = null;
            this.questionIntro.Icon = null;
            this.questionIntro.IconIsButton = false;
            this.questionIntro.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.questionIntro.IsPasswordChat = '\0';
            this.questionIntro.IsSystemPasswordChar = false;
            this.questionIntro.Lines = new string[0];
            this.questionIntro.Location = new System.Drawing.Point(102, 40);
            this.questionIntro.Margin = new System.Windows.Forms.Padding(0);
            this.questionIntro.MaxLength = 1000;
            this.questionIntro.MinimumSize = new System.Drawing.Size(28, 28);
            this.questionIntro.MouseBack = null;
            this.questionIntro.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.questionIntro.Multiline = true;
            this.questionIntro.Name = "questionIntro";
            this.questionIntro.NormlBack = null;
            this.questionIntro.Padding = new System.Windows.Forms.Padding(5);
            this.questionIntro.ReadOnly = false;
            this.questionIntro.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.questionIntro.Size = new System.Drawing.Size(754, 61);
            // 
            // 
            // 
            this.questionIntro.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.questionIntro.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questionIntro.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.questionIntro.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.questionIntro.SkinTxt.MaxLength = 1000;
            this.questionIntro.SkinTxt.Multiline = true;
            this.questionIntro.SkinTxt.Name = "BaseText";
            this.questionIntro.SkinTxt.Size = new System.Drawing.Size(744, 51);
            this.questionIntro.SkinTxt.TabIndex = 0;
            this.questionIntro.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.questionIntro.SkinTxt.WaterText = "";
            this.questionIntro.TabIndex = 10;
            this.questionIntro.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.questionIntro.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.questionIntro.WaterText = "";
            this.questionIntro.WordWrap = true;
            // 
            // skinLabel3
            // 
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.ForeColor = System.Drawing.Color.Black;
            this.skinLabel3.Location = new System.Drawing.Point(19, 40);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(80, 17);
            this.skinLabel3.TabIndex = 13;
            this.skinLabel3.Text = "项目问题描述";
            // 
            // questionType
            // 
            this.questionType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.questionType.FormattingEnabled = true;
            this.questionType.Items.AddRange(new object[] {
            "C#",
            "C++",
            "java",
            "php",
            "Html"});
            this.questionType.Location = new System.Drawing.Point(704, 5);
            this.questionType.Name = "questionType";
            this.questionType.Size = new System.Drawing.Size(152, 24);
            this.questionType.TabIndex = 11;
            this.questionType.WaterText = "";
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.ForeColor = System.Drawing.Color.Black;
            this.skinLabel2.Location = new System.Drawing.Point(666, 9);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(32, 17);
            this.skinLabel2.TabIndex = 12;
            this.skinLabel2.Text = "类别";
            // 
            // questionTitle
            // 
            this.questionTitle.BackColor = System.Drawing.Color.Transparent;
            this.questionTitle.DownBack = null;
            this.questionTitle.Icon = null;
            this.questionTitle.IconIsButton = false;
            this.questionTitle.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.questionTitle.IsPasswordChat = '\0';
            this.questionTitle.IsSystemPasswordChar = false;
            this.questionTitle.Lines = new string[0];
            this.questionTitle.Location = new System.Drawing.Point(56, 2);
            this.questionTitle.Margin = new System.Windows.Forms.Padding(0);
            this.questionTitle.MaxLength = 20;
            this.questionTitle.MinimumSize = new System.Drawing.Size(28, 28);
            this.questionTitle.MouseBack = null;
            this.questionTitle.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.questionTitle.Multiline = false;
            this.questionTitle.Name = "questionTitle";
            this.questionTitle.NormlBack = null;
            this.questionTitle.Padding = new System.Windows.Forms.Padding(5);
            this.questionTitle.ReadOnly = false;
            this.questionTitle.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.questionTitle.Size = new System.Drawing.Size(441, 28);
            // 
            // 
            // 
            this.questionTitle.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.questionTitle.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questionTitle.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.questionTitle.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.questionTitle.SkinTxt.MaxLength = 20;
            this.questionTitle.SkinTxt.Name = "BaseText";
            this.questionTitle.SkinTxt.Size = new System.Drawing.Size(431, 18);
            this.questionTitle.SkinTxt.TabIndex = 0;
            this.questionTitle.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.questionTitle.SkinTxt.WaterText = "";
            this.questionTitle.TabIndex = 9;
            this.questionTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.questionTitle.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.questionTitle.WaterText = "";
            this.questionTitle.WordWrap = true;
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.ForeColor = System.Drawing.Color.Black;
            this.skinLabel1.Location = new System.Drawing.Point(21, 9);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(32, 17);
            this.skinLabel1.TabIndex = 8;
            this.skinLabel1.Text = "标题";
            // 
            // skinPanelAnswer
            // 
            this.skinPanelAnswer.AutoSize = true;
            this.skinPanelAnswer.BackColor = System.Drawing.Color.Transparent;
            this.skinPanelAnswer.Controls.Add(this.answerUpload);
            this.skinPanelAnswer.Controls.Add(this.answerLoad);
            this.skinPanelAnswer.Controls.Add(this.chooseAnswerFile);
            this.skinPanelAnswer.Controls.Add(this.skinLabel26);
            this.skinPanelAnswer.Controls.Add(this.answerIntro);
            this.skinPanelAnswer.Controls.Add(this.skinLabel27);
            this.skinPanelAnswer.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanelAnswer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanelAnswer.DownBack = null;
            this.skinPanelAnswer.Location = new System.Drawing.Point(0, 25);
            this.skinPanelAnswer.MouseBack = null;
            this.skinPanelAnswer.Name = "skinPanelAnswer";
            this.skinPanelAnswer.NormlBack = null;
            this.skinPanelAnswer.Size = new System.Drawing.Size(984, 145);
            this.skinPanelAnswer.TabIndex = 8;
            // 
            // answerUpload
            // 
            this.answerUpload.BackColor = System.Drawing.Color.Transparent;
            this.answerUpload.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.answerUpload.DownBack = null;
            this.answerUpload.Location = new System.Drawing.Point(866, 37);
            this.answerUpload.MouseBack = null;
            this.answerUpload.Name = "answerUpload";
            this.answerUpload.NormlBack = null;
            this.answerUpload.Size = new System.Drawing.Size(71, 61);
            this.answerUpload.TabIndex = 7;
            this.answerUpload.Text = "发布回答";
            this.answerUpload.UseVisualStyleBackColor = false;
            this.answerUpload.Click += new System.EventHandler(this.answerUpload_Click);
            // 
            // answerLoad
            // 
            this.answerLoad.AutoSize = true;
            this.answerLoad.BackColor = System.Drawing.Color.Transparent;
            this.answerLoad.BorderColor = System.Drawing.Color.White;
            this.answerLoad.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.answerLoad.ForeColor = System.Drawing.Color.Black;
            this.answerLoad.Location = new System.Drawing.Point(131, 122);
            this.answerLoad.Name = "answerLoad";
            this.answerLoad.Size = new System.Drawing.Size(32, 17);
            this.answerLoad.TabIndex = 6;
            this.answerLoad.Text = "路径";
            // 
            // chooseAnswerFile
            // 
            this.chooseAnswerFile.BackColor = System.Drawing.Color.Transparent;
            this.chooseAnswerFile.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.chooseAnswerFile.DownBack = null;
            this.chooseAnswerFile.Location = new System.Drawing.Point(50, 119);
            this.chooseAnswerFile.MouseBack = null;
            this.chooseAnswerFile.Name = "chooseAnswerFile";
            this.chooseAnswerFile.NormlBack = null;
            this.chooseAnswerFile.Size = new System.Drawing.Size(75, 23);
            this.chooseAnswerFile.TabIndex = 5;
            this.chooseAnswerFile.Text = "选择文件";
            this.chooseAnswerFile.UseVisualStyleBackColor = false;
            this.chooseAnswerFile.Click += new System.EventHandler(this.chooseAnswerFile_Click);
            // 
            // skinLabel26
            // 
            this.skinLabel26.AutoSize = true;
            this.skinLabel26.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel26.BorderColor = System.Drawing.Color.White;
            this.skinLabel26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel26.ForeColor = System.Drawing.Color.Black;
            this.skinLabel26.Location = new System.Drawing.Point(12, 122);
            this.skinLabel26.Name = "skinLabel26";
            this.skinLabel26.Size = new System.Drawing.Size(32, 17);
            this.skinLabel26.TabIndex = 4;
            this.skinLabel26.Text = "附件";
            // 
            // answerIntro
            // 
            this.answerIntro.AutoScroll = true;
            this.answerIntro.BackColor = System.Drawing.Color.Transparent;
            this.answerIntro.DownBack = null;
            this.answerIntro.Icon = null;
            this.answerIntro.IconIsButton = false;
            this.answerIntro.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.answerIntro.IsPasswordChat = '\0';
            this.answerIntro.IsSystemPasswordChar = false;
            this.answerIntro.Lines = new string[0];
            this.answerIntro.Location = new System.Drawing.Point(95, 17);
            this.answerIntro.Margin = new System.Windows.Forms.Padding(0);
            this.answerIntro.MaxLength = 2000;
            this.answerIntro.MinimumSize = new System.Drawing.Size(28, 28);
            this.answerIntro.MouseBack = null;
            this.answerIntro.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.answerIntro.Multiline = true;
            this.answerIntro.Name = "answerIntro";
            this.answerIntro.NormlBack = null;
            this.answerIntro.Padding = new System.Windows.Forms.Padding(5);
            this.answerIntro.ReadOnly = false;
            this.answerIntro.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.answerIntro.Size = new System.Drawing.Size(754, 81);
            // 
            // 
            // 
            this.answerIntro.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.answerIntro.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.answerIntro.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.answerIntro.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.answerIntro.SkinTxt.MaxLength = 2000;
            this.answerIntro.SkinTxt.Multiline = true;
            this.answerIntro.SkinTxt.Name = "BaseText";
            this.answerIntro.SkinTxt.Size = new System.Drawing.Size(744, 71);
            this.answerIntro.SkinTxt.TabIndex = 0;
            this.answerIntro.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.answerIntro.SkinTxt.WaterText = "";
            this.answerIntro.TabIndex = 2;
            this.answerIntro.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.answerIntro.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.answerIntro.WaterText = "";
            this.answerIntro.WordWrap = true;
            // 
            // skinLabel27
            // 
            this.skinLabel27.AutoSize = true;
            this.skinLabel27.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel27.BorderColor = System.Drawing.Color.White;
            this.skinLabel27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel27.ForeColor = System.Drawing.Color.Black;
            this.skinLabel27.Location = new System.Drawing.Point(12, 17);
            this.skinLabel27.Name = "skinLabel27";
            this.skinLabel27.Size = new System.Drawing.Size(80, 17);
            this.skinLabel27.TabIndex = 3;
            this.skinLabel27.Text = "解决方法描述";
            // 
            // skinToolStrip4
            // 
            this.skinToolStrip4.Arrow = System.Drawing.Color.Black;
            this.skinToolStrip4.Back = System.Drawing.Color.White;
            this.skinToolStrip4.BackRadius = 4;
            this.skinToolStrip4.BackRectangle = new System.Drawing.Rectangle(10, 10, 10, 10);
            this.skinToolStrip4.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.skinToolStrip4.BaseFore = System.Drawing.Color.Black;
            this.skinToolStrip4.BaseForeAnamorphosis = false;
            this.skinToolStrip4.BaseForeAnamorphosisBorder = 4;
            this.skinToolStrip4.BaseForeAnamorphosisColor = System.Drawing.Color.White;
            this.skinToolStrip4.BaseForeOffset = new System.Drawing.Point(0, 0);
            this.skinToolStrip4.BaseHoverFore = System.Drawing.Color.White;
            this.skinToolStrip4.BaseItemAnamorphosis = true;
            this.skinToolStrip4.BaseItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.BaseItemBorderShow = true;
            this.skinToolStrip4.BaseItemDown = ((System.Drawing.Image)(resources.GetObject("skinToolStrip4.BaseItemDown")));
            this.skinToolStrip4.BaseItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.BaseItemMouse = ((System.Drawing.Image)(resources.GetObject("skinToolStrip4.BaseItemMouse")));
            this.skinToolStrip4.BaseItemNorml = null;
            this.skinToolStrip4.BaseItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.BaseItemRadius = 4;
            this.skinToolStrip4.BaseItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip4.BaseItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.BindTabControl = null;
            this.skinToolStrip4.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.skinToolStrip4.Fore = System.Drawing.Color.Black;
            this.skinToolStrip4.GripMargin = new System.Windows.Forms.Padding(2, 2, 4, 2);
            this.skinToolStrip4.HoverFore = System.Drawing.Color.White;
            this.skinToolStrip4.ItemAnamorphosis = true;
            this.skinToolStrip4.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.ItemBorderShow = true;
            this.skinToolStrip4.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip4.ItemRadius = 4;
            this.skinToolStrip4.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.questionshow,
            this.answershow});
            this.skinToolStrip4.Location = new System.Drawing.Point(0, 0);
            this.skinToolStrip4.Name = "skinToolStrip4";
            this.skinToolStrip4.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip4.Size = new System.Drawing.Size(984, 25);
            this.skinToolStrip4.SkinAllColor = true;
            this.skinToolStrip4.TabIndex = 0;
            this.skinToolStrip4.Text = "skinToolStrip4";
            this.skinToolStrip4.TitleAnamorphosis = true;
            this.skinToolStrip4.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.skinToolStrip4.TitleRadius = 4;
            this.skinToolStrip4.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // questionshow
            // 
            this.questionshow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.questionshow.Image = ((System.Drawing.Image)(resources.GetObject("questionshow.Image")));
            this.questionshow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.questionshow.Name = "questionshow";
            this.questionshow.Size = new System.Drawing.Size(23, 22);
            this.questionshow.Text = "toolStripButton3";
            this.questionshow.Click += new System.EventHandler(this.questionshow_Click);
            // 
            // answershow
            // 
            this.answershow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.answershow.Image = ((System.Drawing.Image)(resources.GetObject("answershow.Image")));
            this.answershow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.answershow.Name = "answershow";
            this.answershow.Size = new System.Drawing.Size(23, 22);
            this.answershow.Text = "toolStripButton4";
            this.answershow.Click += new System.EventHandler(this.answershow_Click);
            // 
            // root
            // 
            this.root.BackColor = System.Drawing.Color.White;
            this.root.Controls.Add(this.rootcontrol);
            this.root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.root.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.root.ForeColor = System.Drawing.Color.White;
            this.root.ImageIndex = 2;
            this.root.Location = new System.Drawing.Point(0, 36);
            this.root.Name = "root";
            this.root.Size = new System.Drawing.Size(984, 547);
            this.root.TabIndex = 3;
            this.root.TabItemImage = null;
            this.root.Text = "管理员操作项";
            // 
            // rootcontrol
            // 
            this.rootcontrol.AnimatorType = CCWin.SkinControl.AnimationType.HorizSlide;
            this.rootcontrol.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.rootcontrol.Controls.Add(this.bookmanage);
            this.rootcontrol.Controls.Add(this.projectmanage);
            this.rootcontrol.Controls.Add(this.usermanage);
            this.rootcontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rootcontrol.HeadBack = null;
            this.rootcontrol.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.rootcontrol.ItemSize = new System.Drawing.Size(70, 36);
            this.rootcontrol.Location = new System.Drawing.Point(0, 0);
            this.rootcontrol.Name = "rootcontrol";
            this.rootcontrol.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageArrowDown")));
            this.rootcontrol.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageArrowHover")));
            this.rootcontrol.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageCloseHover")));
            this.rootcontrol.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageCloseNormal")));
            this.rootcontrol.PageDown = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageDown")));
            this.rootcontrol.PageHover = ((System.Drawing.Image)(resources.GetObject("rootcontrol.PageHover")));
            this.rootcontrol.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.rootcontrol.PageNorml = null;
            this.rootcontrol.SelectedIndex = 2;
            this.rootcontrol.Size = new System.Drawing.Size(984, 547);
            this.rootcontrol.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.rootcontrol.TabIndex = 0;
            this.rootcontrol.Selected += new System.Windows.Forms.TabControlEventHandler(this.rootcontrol_Selected);
            // 
            // bookmanage
            // 
            this.bookmanage.BackColor = System.Drawing.Color.Gray;
            this.bookmanage.Controls.Add(this.skinPanel3);
            this.bookmanage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookmanage.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookmanage.Location = new System.Drawing.Point(0, 36);
            this.bookmanage.Name = "bookmanage";
            this.bookmanage.Size = new System.Drawing.Size(984, 511);
            this.bookmanage.TabIndex = 0;
            this.bookmanage.TabItemImage = null;
            this.bookmanage.Text = "书本管理";
            // 
            // skinPanel3
            // 
            this.skinPanel3.AutoScroll = true;
            this.skinPanel3.AutoSize = true;
            this.skinPanel3.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel3.Controls.Add(this.skinPanel4);
            this.skinPanel3.Controls.Add(this.skinPanel8);
            this.skinPanel3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanel3.DownBack = null;
            this.skinPanel3.Location = new System.Drawing.Point(0, 0);
            this.skinPanel3.MouseBack = null;
            this.skinPanel3.Name = "skinPanel3";
            this.skinPanel3.NormlBack = null;
            this.skinPanel3.Size = new System.Drawing.Size(984, 511);
            this.skinPanel3.TabIndex = 1;
            // 
            // skinPanel4
            // 
            this.skinPanel4.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel4.Controls.Add(this.bookinfolist);
            this.skinPanel4.Controls.Add(this.skinToolStrip1);
            this.skinPanel4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinPanel4.DownBack = null;
            this.skinPanel4.Location = new System.Drawing.Point(0, 32);
            this.skinPanel4.MouseBack = null;
            this.skinPanel4.Name = "skinPanel4";
            this.skinPanel4.NormlBack = null;
            this.skinPanel4.Size = new System.Drawing.Size(984, 479);
            this.skinPanel4.TabIndex = 19;
            // 
            // bookinfolist
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.bookinfolist.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.bookinfolist.AutoGenerateColumns = false;
            this.bookinfolist.BackgroundColor = System.Drawing.SystemColors.Window;
            this.bookinfolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bookinfolist.ColumnFont = null;
            this.bookinfolist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bookinfolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.bookinfolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookinfolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookselect,
            this.bookinfoset,
            this.nameDataGridViewTextBoxColumn2,
            this.typeDataGridViewTextBoxColumn1,
            this.autorDataGridViewTextBoxColumn1,
            this.pubnameDataGridViewTextBoxColumn1,
            this.dateDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.codeDataGridViewTextBoxColumn,
            this.pagecodeDataGridViewTextBoxColumn});
            this.bookinfolist.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.bookinfolist.DataSource = this.tbbookBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bookinfolist.DefaultCellStyle = dataGridViewCellStyle7;
            this.bookinfolist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookinfolist.EnableHeadersVisualStyles = false;
            this.bookinfolist.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bookinfolist.HeadFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bookinfolist.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.bookinfolist.Location = new System.Drawing.Point(0, 0);
            this.bookinfolist.Name = "bookinfolist";
            this.bookinfolist.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bookinfolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.bookinfolist.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.bookinfolist.RowTemplate.Height = 23;
            this.bookinfolist.Size = new System.Drawing.Size(984, 454);
            this.bookinfolist.TabIndex = 7;
            this.bookinfolist.TitleBack = null;
            this.bookinfolist.TitleBackColorBegin = System.Drawing.Color.White;
            this.bookinfolist.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            this.bookinfolist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bookinfolist_CellContentClick);
            // 
            // bookselect
            // 
            this.bookselect.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.bookselect.FalseValue = "False";
            this.bookselect.Frozen = true;
            this.bookselect.HeaderText = "选择";
            this.bookselect.Name = "bookselect";
            this.bookselect.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.bookselect.TrueValue = "True";
            this.bookselect.Width = 37;
            // 
            // bookinfoset
            // 
            this.bookinfoset.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.bookinfoset.Frozen = true;
            this.bookinfoset.HeaderText = "编辑内容";
            this.bookinfoset.Name = "bookinfoset";
            this.bookinfoset.Text = "  编辑";
            this.bookinfoset.UseColumnTextForButtonValue = true;
            this.bookinfoset.Width = 61;
            // 
            // nameDataGridViewTextBoxColumn2
            // 
            this.nameDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn2.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn2.HeaderText = "书名";
            this.nameDataGridViewTextBoxColumn2.Name = "nameDataGridViewTextBoxColumn2";
            this.nameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // typeDataGridViewTextBoxColumn1
            // 
            this.typeDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.typeDataGridViewTextBoxColumn1.DataPropertyName = "type";
            this.typeDataGridViewTextBoxColumn1.HeaderText = "类型";
            this.typeDataGridViewTextBoxColumn1.Name = "typeDataGridViewTextBoxColumn1";
            this.typeDataGridViewTextBoxColumn1.ReadOnly = true;
            this.typeDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // autorDataGridViewTextBoxColumn1
            // 
            this.autorDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.autorDataGridViewTextBoxColumn1.DataPropertyName = "autor";
            this.autorDataGridViewTextBoxColumn1.HeaderText = "作者";
            this.autorDataGridViewTextBoxColumn1.Name = "autorDataGridViewTextBoxColumn1";
            this.autorDataGridViewTextBoxColumn1.ReadOnly = true;
            this.autorDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pubnameDataGridViewTextBoxColumn1
            // 
            this.pubnameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.pubnameDataGridViewTextBoxColumn1.DataPropertyName = "pubname";
            this.pubnameDataGridViewTextBoxColumn1.HeaderText = "出版社";
            this.pubnameDataGridViewTextBoxColumn1.Name = "pubnameDataGridViewTextBoxColumn1";
            this.pubnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.pubnameDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "日期";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "价格";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // codeDataGridViewTextBoxColumn
            // 
            this.codeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.codeDataGridViewTextBoxColumn.DataPropertyName = "code";
            this.codeDataGridViewTextBoxColumn.HeaderText = "标识码";
            this.codeDataGridViewTextBoxColumn.Name = "codeDataGridViewTextBoxColumn";
            this.codeDataGridViewTextBoxColumn.ReadOnly = true;
            this.codeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pagecodeDataGridViewTextBoxColumn
            // 
            this.pagecodeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.pagecodeDataGridViewTextBoxColumn.DataPropertyName = "pagecode";
            this.pagecodeDataGridViewTextBoxColumn.HeaderText = "页码数";
            this.pagecodeDataGridViewTextBoxColumn.Name = "pagecodeDataGridViewTextBoxColumn";
            this.pagecodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.pagecodeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // skinToolStrip1
            // 
            this.skinToolStrip1.Arrow = System.Drawing.Color.Black;
            this.skinToolStrip1.Back = System.Drawing.Color.White;
            this.skinToolStrip1.BackRadius = 4;
            this.skinToolStrip1.BackRectangle = new System.Drawing.Rectangle(10, 10, 10, 10);
            this.skinToolStrip1.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.skinToolStrip1.BaseFore = System.Drawing.Color.Black;
            this.skinToolStrip1.BaseForeAnamorphosis = false;
            this.skinToolStrip1.BaseForeAnamorphosisBorder = 4;
            this.skinToolStrip1.BaseForeAnamorphosisColor = System.Drawing.Color.White;
            this.skinToolStrip1.BaseForeOffset = new System.Drawing.Point(0, 0);
            this.skinToolStrip1.BaseHoverFore = System.Drawing.Color.White;
            this.skinToolStrip1.BaseItemAnamorphosis = true;
            this.skinToolStrip1.BaseItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.BaseItemBorderShow = true;
            this.skinToolStrip1.BaseItemDown = ((System.Drawing.Image)(resources.GetObject("skinToolStrip1.BaseItemDown")));
            this.skinToolStrip1.BaseItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.BaseItemMouse = ((System.Drawing.Image)(resources.GetObject("skinToolStrip1.BaseItemMouse")));
            this.skinToolStrip1.BaseItemNorml = null;
            this.skinToolStrip1.BaseItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.BaseItemRadius = 4;
            this.skinToolStrip1.BaseItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip1.BaseItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.BindTabControl = null;
            this.skinToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.skinToolStrip1.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.skinToolStrip1.Fore = System.Drawing.Color.Black;
            this.skinToolStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 4, 2);
            this.skinToolStrip1.HoverFore = System.Drawing.Color.White;
            this.skinToolStrip1.ItemAnamorphosis = true;
            this.skinToolStrip1.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.ItemBorderShow = true;
            this.skinToolStrip1.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip1.ItemRadius = 4;
            this.skinToolStrip1.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bookadd,
            this.bookdelet,
            this.bookrefrsh});
            this.skinToolStrip1.Location = new System.Drawing.Point(0, 454);
            this.skinToolStrip1.Name = "skinToolStrip1";
            this.skinToolStrip1.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip1.Size = new System.Drawing.Size(984, 25);
            this.skinToolStrip1.SkinAllColor = true;
            this.skinToolStrip1.TabIndex = 5;
            this.skinToolStrip1.Text = "skinToolStrip1";
            this.skinToolStrip1.TitleAnamorphosis = true;
            this.skinToolStrip1.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.skinToolStrip1.TitleRadius = 4;
            this.skinToolStrip1.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // bookadd
            // 
            this.bookadd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bookadd.Image = ((System.Drawing.Image)(resources.GetObject("bookadd.Image")));
            this.bookadd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bookadd.Name = "bookadd";
            this.bookadd.Size = new System.Drawing.Size(23, 22);
            this.bookadd.Text = "toolStripButton1";
            this.bookadd.Click += new System.EventHandler(this.bookadd_Click);
            // 
            // bookdelet
            // 
            this.bookdelet.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bookdelet.Image = ((System.Drawing.Image)(resources.GetObject("bookdelet.Image")));
            this.bookdelet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bookdelet.Name = "bookdelet";
            this.bookdelet.Size = new System.Drawing.Size(23, 22);
            this.bookdelet.Text = "toolStripButton2";
            this.bookdelet.Click += new System.EventHandler(this.bookdelet_Click);
            // 
            // bookrefrsh
            // 
            this.bookrefrsh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bookrefrsh.Image = ((System.Drawing.Image)(resources.GetObject("bookrefrsh.Image")));
            this.bookrefrsh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bookrefrsh.Name = "bookrefrsh";
            this.bookrefrsh.Size = new System.Drawing.Size(23, 22);
            this.bookrefrsh.Text = "toolStripButton1";
            this.bookrefrsh.Click += new System.EventHandler(this.bookrefrsh_Click);
            // 
            // skinPanel8
            // 
            this.skinPanel8.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel8.Controls.Add(this.bookmanagekey);
            this.skinPanel8.Controls.Add(this.skinLabel6);
            this.skinPanel8.Controls.Add(this.booksearchtype);
            this.skinPanel8.Controls.Add(this.bookmanagesearch);
            this.skinPanel8.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.skinPanel8.DownBack = null;
            this.skinPanel8.Location = new System.Drawing.Point(0, 0);
            this.skinPanel8.MouseBack = null;
            this.skinPanel8.Name = "skinPanel8";
            this.skinPanel8.NormlBack = null;
            this.skinPanel8.Size = new System.Drawing.Size(984, 32);
            this.skinPanel8.TabIndex = 18;
            // 
            // bookmanagekey
            // 
            this.bookmanagekey.BackColor = System.Drawing.Color.Transparent;
            this.bookmanagekey.DownBack = null;
            this.bookmanagekey.Icon = null;
            this.bookmanagekey.IconIsButton = false;
            this.bookmanagekey.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookmanagekey.IsPasswordChat = '\0';
            this.bookmanagekey.IsSystemPasswordChar = false;
            this.bookmanagekey.Lines = new string[0];
            this.bookmanagekey.Location = new System.Drawing.Point(745, 1);
            this.bookmanagekey.Margin = new System.Windows.Forms.Padding(0);
            this.bookmanagekey.MaxLength = 32767;
            this.bookmanagekey.MinimumSize = new System.Drawing.Size(28, 28);
            this.bookmanagekey.MouseBack = null;
            this.bookmanagekey.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.bookmanagekey.Multiline = false;
            this.bookmanagekey.Name = "bookmanagekey";
            this.bookmanagekey.NormlBack = null;
            this.bookmanagekey.Padding = new System.Windows.Forms.Padding(5);
            this.bookmanagekey.ReadOnly = false;
            this.bookmanagekey.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bookmanagekey.Size = new System.Drawing.Size(203, 28);
            // 
            // 
            // 
            this.bookmanagekey.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bookmanagekey.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookmanagekey.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.bookmanagekey.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.bookmanagekey.SkinTxt.Name = "BaseText";
            this.bookmanagekey.SkinTxt.Size = new System.Drawing.Size(193, 18);
            this.bookmanagekey.SkinTxt.TabIndex = 0;
            this.bookmanagekey.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookmanagekey.SkinTxt.WaterText = "输入关键字";
            this.bookmanagekey.TabIndex = 6;
            this.bookmanagekey.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bookmanagekey.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.bookmanagekey.WaterText = "输入关键字";
            this.bookmanagekey.WordWrap = true;
            // 
            // skinLabel6
            // 
            this.skinLabel6.AutoSize = true;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.ForeColor = System.Drawing.Color.Black;
            this.skinLabel6.Location = new System.Drawing.Point(624, 6);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(32, 17);
            this.skinLabel6.TabIndex = 2;
            this.skinLabel6.Text = "搜索";
            // 
            // booksearchtype
            // 
            this.booksearchtype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.booksearchtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.booksearchtype.FormattingEnabled = true;
            this.booksearchtype.Items.AddRange(new object[] {
            "书名",
            "类型",
            "出版社",
            "作者",
            "年份"});
            this.booksearchtype.Location = new System.Drawing.Point(657, 3);
            this.booksearchtype.Name = "booksearchtype";
            this.booksearchtype.Size = new System.Drawing.Size(85, 24);
            this.booksearchtype.TabIndex = 5;
            this.booksearchtype.WaterText = "选择类型";
            // 
            // bookmanagesearch
            // 
            this.bookmanagesearch.BackColor = System.Drawing.Color.Transparent;
            this.bookmanagesearch.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.bookmanagesearch.DownBack = global::LibraryUI_rebuild.Properties.Resources.search;
            this.bookmanagesearch.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.bookmanagesearch.Location = new System.Drawing.Point(951, 1);
            this.bookmanagesearch.MouseBack = global::LibraryUI_rebuild.Properties.Resources.search_gray;
            this.bookmanagesearch.Name = "bookmanagesearch";
            this.bookmanagesearch.NormlBack = global::LibraryUI_rebuild.Properties.Resources._002_white;
            this.bookmanagesearch.Size = new System.Drawing.Size(28, 28);
            this.bookmanagesearch.TabIndex = 1;
            this.bookmanagesearch.UseVisualStyleBackColor = false;
            this.bookmanagesearch.Click += new System.EventHandler(this.search_Click);
            // 
            // projectmanage
            // 
            this.projectmanage.BackColor = System.Drawing.Color.Gray;
            this.projectmanage.Controls.Add(this.skinTabControl1);
            this.projectmanage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.projectmanage.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.projectmanage.Location = new System.Drawing.Point(0, 36);
            this.projectmanage.Name = "projectmanage";
            this.projectmanage.Size = new System.Drawing.Size(984, 511);
            this.projectmanage.TabIndex = 1;
            this.projectmanage.TabItemImage = null;
            this.projectmanage.Text = "项目管理";
            // 
            // skinTabControl1
            // 
            this.skinTabControl1.AnimatorType = CCWin.SkinControl.AnimationType.HorizSlide;
            this.skinTabControl1.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.skinTabControl1.Controls.Add(this.questioncontrol);
            this.skinTabControl1.Controls.Add(this.answercontrol);
            this.skinTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabControl1.HeadBack = null;
            this.skinTabControl1.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.skinTabControl1.ItemSize = new System.Drawing.Size(70, 36);
            this.skinTabControl1.Location = new System.Drawing.Point(0, 0);
            this.skinTabControl1.Name = "skinTabControl1";
            this.skinTabControl1.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageArrowDown")));
            this.skinTabControl1.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageArrowHover")));
            this.skinTabControl1.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageCloseHover")));
            this.skinTabControl1.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageCloseNormal")));
            this.skinTabControl1.PageDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageDown")));
            this.skinTabControl1.PageHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl1.PageHover")));
            this.skinTabControl1.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.skinTabControl1.PageNorml = null;
            this.skinTabControl1.SelectedIndex = 0;
            this.skinTabControl1.Size = new System.Drawing.Size(984, 511);
            this.skinTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.skinTabControl1.TabIndex = 0;
            // 
            // questioncontrol
            // 
            this.questioncontrol.BackColor = System.Drawing.Color.White;
            this.questioncontrol.Controls.Add(this.skinToolStrip5);
            this.questioncontrol.Controls.Add(this.questionControlList);
            this.questioncontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questioncontrol.Location = new System.Drawing.Point(0, 36);
            this.questioncontrol.Name = "questioncontrol";
            this.questioncontrol.Size = new System.Drawing.Size(984, 475);
            this.questioncontrol.TabIndex = 0;
            this.questioncontrol.TabItemImage = null;
            this.questioncontrol.Text = "问题管理";
            // 
            // skinToolStrip5
            // 
            this.skinToolStrip5.Arrow = System.Drawing.Color.Black;
            this.skinToolStrip5.Back = System.Drawing.Color.White;
            this.skinToolStrip5.BackRadius = 4;
            this.skinToolStrip5.BackRectangle = new System.Drawing.Rectangle(10, 10, 10, 10);
            this.skinToolStrip5.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.skinToolStrip5.BaseFore = System.Drawing.Color.Black;
            this.skinToolStrip5.BaseForeAnamorphosis = false;
            this.skinToolStrip5.BaseForeAnamorphosisBorder = 4;
            this.skinToolStrip5.BaseForeAnamorphosisColor = System.Drawing.Color.White;
            this.skinToolStrip5.BaseForeOffset = new System.Drawing.Point(0, 0);
            this.skinToolStrip5.BaseHoverFore = System.Drawing.Color.White;
            this.skinToolStrip5.BaseItemAnamorphosis = true;
            this.skinToolStrip5.BaseItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.BaseItemBorderShow = true;
            this.skinToolStrip5.BaseItemDown = ((System.Drawing.Image)(resources.GetObject("skinToolStrip5.BaseItemDown")));
            this.skinToolStrip5.BaseItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.BaseItemMouse = ((System.Drawing.Image)(resources.GetObject("skinToolStrip5.BaseItemMouse")));
            this.skinToolStrip5.BaseItemNorml = null;
            this.skinToolStrip5.BaseItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.BaseItemRadius = 4;
            this.skinToolStrip5.BaseItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip5.BaseItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.BindTabControl = null;
            this.skinToolStrip5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.skinToolStrip5.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.skinToolStrip5.Fore = System.Drawing.Color.Black;
            this.skinToolStrip5.GripMargin = new System.Windows.Forms.Padding(2, 2, 4, 2);
            this.skinToolStrip5.HoverFore = System.Drawing.Color.White;
            this.skinToolStrip5.ItemAnamorphosis = true;
            this.skinToolStrip5.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.ItemBorderShow = true;
            this.skinToolStrip5.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinToolStrip5.ItemRadius = 4;
            this.skinToolStrip5.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3});
            this.skinToolStrip5.Location = new System.Drawing.Point(0, 450);
            this.skinToolStrip5.Name = "skinToolStrip5";
            this.skinToolStrip5.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinToolStrip5.Size = new System.Drawing.Size(984, 25);
            this.skinToolStrip5.SkinAllColor = true;
            this.skinToolStrip5.TabIndex = 1;
            this.skinToolStrip5.Text = "skinToolStrip5";
            this.skinToolStrip5.TitleAnamorphosis = true;
            this.skinToolStrip5.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.skinToolStrip5.TitleRadius = 4;
            this.skinToolStrip5.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // questionControlList
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.questionControlList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.questionControlList.AutoGenerateColumns = false;
            this.questionControlList.BackgroundColor = System.Drawing.SystemColors.Window;
            this.questionControlList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.questionControlList.ColumnFont = null;
            this.questionControlList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.questionControlList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.questionControlList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.questionControlList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.select,
            this.titleDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn2,
            this.aboutDataGridViewTextBoxColumn,
            this.filenameDataGridViewTextBoxColumn,
            this.uploadTimeDataGridViewTextBoxColumn,
            this.questionerIdDataGridViewTextBoxColumn});
            this.questionControlList.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.questionControlList.DataSource = this.tbquestionBindingSource1;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.questionControlList.DefaultCellStyle = dataGridViewCellStyle11;
            this.questionControlList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questionControlList.EnableHeadersVisualStyles = false;
            this.questionControlList.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.questionControlList.HeadFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.questionControlList.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.questionControlList.Location = new System.Drawing.Point(0, 0);
            this.questionControlList.Name = "questionControlList";
            this.questionControlList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.questionControlList.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.questionControlList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.questionControlList.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.questionControlList.RowTemplate.Height = 23;
            this.questionControlList.Size = new System.Drawing.Size(984, 475);
            this.questionControlList.TabIndex = 0;
            this.questionControlList.TitleBack = null;
            this.questionControlList.TitleBackColorBegin = System.Drawing.Color.White;
            this.questionControlList.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            // 
            // select
            // 
            this.select.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.select.FalseValue = "False";
            this.select.HeaderText = "选择";
            this.select.Name = "select";
            this.select.TrueValue = "True";
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "title";
            this.titleDataGridViewTextBoxColumn.HeaderText = "标题";
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            // 
            // typeDataGridViewTextBoxColumn2
            // 
            this.typeDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.typeDataGridViewTextBoxColumn2.DataPropertyName = "type";
            this.typeDataGridViewTextBoxColumn2.HeaderText = "类型";
            this.typeDataGridViewTextBoxColumn2.Name = "typeDataGridViewTextBoxColumn2";
            // 
            // aboutDataGridViewTextBoxColumn
            // 
            this.aboutDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.aboutDataGridViewTextBoxColumn.DataPropertyName = "about";
            this.aboutDataGridViewTextBoxColumn.HeaderText = "内容";
            this.aboutDataGridViewTextBoxColumn.Name = "aboutDataGridViewTextBoxColumn";
            // 
            // filenameDataGridViewTextBoxColumn
            // 
            this.filenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.filenameDataGridViewTextBoxColumn.DataPropertyName = "filename";
            this.filenameDataGridViewTextBoxColumn.HeaderText = "文件名";
            this.filenameDataGridViewTextBoxColumn.Name = "filenameDataGridViewTextBoxColumn";
            // 
            // uploadTimeDataGridViewTextBoxColumn
            // 
            this.uploadTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.uploadTimeDataGridViewTextBoxColumn.DataPropertyName = "uploadTime";
            this.uploadTimeDataGridViewTextBoxColumn.HeaderText = "上传时间";
            this.uploadTimeDataGridViewTextBoxColumn.Name = "uploadTimeDataGridViewTextBoxColumn";
            // 
            // questionerIdDataGridViewTextBoxColumn
            // 
            this.questionerIdDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.questionerIdDataGridViewTextBoxColumn.DataPropertyName = "questionerId";
            this.questionerIdDataGridViewTextBoxColumn.HeaderText = "提问人";
            this.questionerIdDataGridViewTextBoxColumn.Name = "questionerIdDataGridViewTextBoxColumn";
            // 
            // tbquestionBindingSource1
            // 
            this.tbquestionBindingSource1.DataMember = "tb_question";
            this.tbquestionBindingSource1.DataSource = this.db_libaryDataSet3;
            // 
            // db_libaryDataSet3
            // 
            this.db_libaryDataSet3.DataSetName = "db_libaryDataSet3";
            this.db_libaryDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // answercontrol
            // 
            this.answercontrol.BackColor = System.Drawing.Color.White;
            this.answercontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.answercontrol.Location = new System.Drawing.Point(0, 36);
            this.answercontrol.Name = "answercontrol";
            this.answercontrol.Size = new System.Drawing.Size(984, 475);
            this.answercontrol.TabIndex = 1;
            this.answercontrol.TabItemImage = null;
            this.answercontrol.Text = "回答管理";
            // 
            // usermanage
            // 
            this.usermanage.BackColor = System.Drawing.Color.Gray;
            this.usermanage.Controls.Add(this.deletuser);
            this.usermanage.Controls.Add(this.adduser);
            this.usermanage.Controls.Add(this.userinfolist);
            this.usermanage.Controls.Add(this.skinLabel8);
            this.usermanage.Controls.Add(this.fresh);
            this.usermanage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.usermanage.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.usermanage.Location = new System.Drawing.Point(0, 36);
            this.usermanage.Name = "usermanage";
            this.usermanage.Size = new System.Drawing.Size(984, 511);
            this.usermanage.TabIndex = 2;
            this.usermanage.TabItemImage = null;
            this.usermanage.Text = "用户管理";
            // 
            // deletuser
            // 
            this.deletuser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deletuser.BackColor = System.Drawing.Color.Transparent;
            this.deletuser.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.deletuser.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.deletuser.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.deletuser.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deletuser.ForeColor = System.Drawing.Color.Black;
            this.deletuser.Location = new System.Drawing.Point(858, 160);
            this.deletuser.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.deletuser.Name = "deletuser";
            this.deletuser.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.deletuser.Size = new System.Drawing.Size(92, 28);
            this.deletuser.TabIndex = 9;
            this.deletuser.Text = "删除用户";
            this.deletuser.UseVisualStyleBackColor = false;
            this.deletuser.Click += new System.EventHandler(this.deletuser_Click);
            // 
            // adduser
            // 
            this.adduser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.adduser.BackColor = System.Drawing.Color.Transparent;
            this.adduser.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.adduser.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.adduser.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.adduser.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.adduser.ForeColor = System.Drawing.Color.Black;
            this.adduser.Location = new System.Drawing.Point(858, 106);
            this.adduser.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.adduser.Name = "adduser";
            this.adduser.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.adduser.Size = new System.Drawing.Size(92, 28);
            this.adduser.TabIndex = 8;
            this.adduser.Text = "新增用户";
            this.adduser.UseVisualStyleBackColor = false;
            this.adduser.Click += new System.EventHandler(this.adduser_Click);
            // 
            // userinfolist
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.userinfolist.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle14;
            this.userinfolist.AutoGenerateColumns = false;
            this.userinfolist.BackgroundColor = System.Drawing.SystemColors.Window;
            this.userinfolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.userinfolist.ColumnFont = null;
            this.userinfolist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.userinfolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.userinfolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userinfolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.selectuser,
            this.levelchange,
            this.nameDataGridViewTextBoxColumn1,
            this.studentnameDataGridViewTextBoxColumn,
            this.studentidDataGridViewTextBoxColumn,
            this.subjectDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.qqDataGridViewTextBoxColumn,
            this.levelDataGridViewCheckBoxColumn,
            this.borrownumDataGridViewTextBoxColumn,
            this.onlineDataGridViewCheckBoxColumn});
            this.userinfolist.ColumnSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.userinfolist.DataSource = this.tbUserBindingSource;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.userinfolist.DefaultCellStyle = dataGridViewCellStyle16;
            this.userinfolist.EnableHeadersVisualStyles = false;
            this.userinfolist.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userinfolist.HeadFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userinfolist.HeadSelectForeColor = System.Drawing.SystemColors.HighlightText;
            this.userinfolist.Location = new System.Drawing.Point(29, 47);
            this.userinfolist.Name = "userinfolist";
            this.userinfolist.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.userinfolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.userinfolist.RowsDefaultCellStyle = dataGridViewCellStyle17;
            this.userinfolist.RowTemplate.Height = 23;
            this.userinfolist.Size = new System.Drawing.Size(776, 440);
            this.userinfolist.TabIndex = 7;
            this.userinfolist.TitleBack = null;
            this.userinfolist.TitleBackColorBegin = System.Drawing.Color.White;
            this.userinfolist.TitleBackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(196)))), ((int)(((byte)(242)))));
            this.userinfolist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userinfolist_CellContentClick);
            // 
            // selectuser
            // 
            this.selectuser.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.selectuser.FalseValue = "False";
            this.selectuser.Frozen = true;
            this.selectuser.HeaderText = "选择";
            this.selectuser.Name = "selectuser";
            this.selectuser.TrueValue = "True";
            this.selectuser.Width = 37;
            // 
            // levelchange
            // 
            this.levelchange.Frozen = true;
            this.levelchange.HeaderText = "权限变更";
            this.levelchange.Name = "levelchange";
            this.levelchange.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.levelchange.Text = "     变     更     ";
            this.levelchange.UseColumnTextForButtonValue = true;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "用户名";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            // 
            // studentnameDataGridViewTextBoxColumn
            // 
            this.studentnameDataGridViewTextBoxColumn.DataPropertyName = "student_name";
            this.studentnameDataGridViewTextBoxColumn.HeaderText = "学生姓名";
            this.studentnameDataGridViewTextBoxColumn.Name = "studentnameDataGridViewTextBoxColumn";
            // 
            // studentidDataGridViewTextBoxColumn
            // 
            this.studentidDataGridViewTextBoxColumn.DataPropertyName = "student_id";
            this.studentidDataGridViewTextBoxColumn.HeaderText = "学号";
            this.studentidDataGridViewTextBoxColumn.Name = "studentidDataGridViewTextBoxColumn";
            // 
            // subjectDataGridViewTextBoxColumn
            // 
            this.subjectDataGridViewTextBoxColumn.DataPropertyName = "subject";
            this.subjectDataGridViewTextBoxColumn.HeaderText = "学科";
            this.subjectDataGridViewTextBoxColumn.Name = "subjectDataGridViewTextBoxColumn";
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "电话";
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            // 
            // qqDataGridViewTextBoxColumn
            // 
            this.qqDataGridViewTextBoxColumn.DataPropertyName = "qq";
            this.qqDataGridViewTextBoxColumn.HeaderText = "QQ";
            this.qqDataGridViewTextBoxColumn.Name = "qqDataGridViewTextBoxColumn";
            // 
            // levelDataGridViewCheckBoxColumn
            // 
            this.levelDataGridViewCheckBoxColumn.DataPropertyName = "level";
            this.levelDataGridViewCheckBoxColumn.HeaderText = "权限";
            this.levelDataGridViewCheckBoxColumn.Name = "levelDataGridViewCheckBoxColumn";
            // 
            // borrownumDataGridViewTextBoxColumn
            // 
            this.borrownumDataGridViewTextBoxColumn.DataPropertyName = "borrownum";
            this.borrownumDataGridViewTextBoxColumn.HeaderText = "借书数目";
            this.borrownumDataGridViewTextBoxColumn.Name = "borrownumDataGridViewTextBoxColumn";
            // 
            // onlineDataGridViewCheckBoxColumn
            // 
            this.onlineDataGridViewCheckBoxColumn.DataPropertyName = "online";
            this.onlineDataGridViewCheckBoxColumn.HeaderText = "在线";
            this.onlineDataGridViewCheckBoxColumn.Name = "onlineDataGridViewCheckBoxColumn";
            // 
            // tbUserBindingSource
            // 
            this.tbUserBindingSource.DataMember = "tb_User";
            this.tbUserBindingSource.DataSource = this.db_libaryDataSet;
            // 
            // skinLabel8
            // 
            this.skinLabel8.AutoSize = true;
            this.skinLabel8.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel8.BorderColor = System.Drawing.Color.White;
            this.skinLabel8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel8.ForeColor = System.Drawing.Color.Black;
            this.skinLabel8.Location = new System.Drawing.Point(31, 17);
            this.skinLabel8.Name = "skinLabel8";
            this.skinLabel8.Size = new System.Drawing.Size(56, 17);
            this.skinLabel8.TabIndex = 4;
            this.skinLabel8.Text = "用户列表";
            // 
            // fresh
            // 
            this.fresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fresh.BackColor = System.Drawing.Color.Transparent;
            this.fresh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.fresh.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.fresh.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.fresh.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fresh.ForeColor = System.Drawing.Color.Black;
            this.fresh.Location = new System.Drawing.Point(858, 48);
            this.fresh.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.fresh.Name = "fresh";
            this.fresh.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.fresh.Size = new System.Drawing.Size(92, 28);
            this.fresh.TabIndex = 1;
            this.fresh.Text = "刷     新";
            this.fresh.UseVisualStyleBackColor = false;
            this.fresh.Click += new System.EventHandler(this.fresh_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "012.png");
            this.imageList1.Images.SetKeyName(1, "043.png");
            this.imageList1.Images.SetKeyName(2, "051.png");
            this.imageList1.Images.SetKeyName(3, "002.png");
            // 
            // settingmenu
            // 
            this.settingmenu.Arrow = System.Drawing.Color.Black;
            this.settingmenu.Back = System.Drawing.Color.White;
            this.settingmenu.BackRadius = 4;
            this.settingmenu.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.settingmenu.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.settingmenu.Fore = System.Drawing.Color.Black;
            this.settingmenu.HoverFore = System.Drawing.Color.White;
            this.settingmenu.ItemAnamorphosis = true;
            this.settingmenu.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.settingmenu.ItemBorderShow = true;
            this.settingmenu.ItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.settingmenu.ItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.settingmenu.ItemRadius = 4;
            this.settingmenu.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.settingmenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于ToolStripMenuItem,
            this.登出ToolStripMenuItem});
            this.settingmenu.ItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.settingmenu.Name = "settingmenu";
            this.settingmenu.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.settingmenu.Size = new System.Drawing.Size(101, 48);
            this.settingmenu.SkinAllColor = true;
            this.settingmenu.TitleAnamorphosis = true;
            this.settingmenu.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.settingmenu.TitleRadius = 4;
            this.settingmenu.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.关于ToolStripMenuItem.Text = "关于";
            // 
            // 登出ToolStripMenuItem
            // 
            this.登出ToolStripMenuItem.Name = "登出ToolStripMenuItem";
            this.登出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.登出ToolStripMenuItem.Text = "登出";
            this.登出ToolStripMenuItem.Click += new System.EventHandler(this.登出ToolStripMenuItem_Click);
            // 
            // setting
            // 
            this.setting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.setting.BackColor = System.Drawing.Color.Transparent;
            this.setting.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.setting.DownBack = global::LibraryUI_rebuild.Properties.Resources.btn_set_press;
            this.setting.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.setting.Location = new System.Drawing.Point(862, -1);
            this.setting.MouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_set_hover;
            this.setting.Name = "setting";
            this.setting.NormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_set_normal;
            this.setting.Size = new System.Drawing.Size(28, 20);
            this.setting.TabIndex = 1;
            this.setting.UseVisualStyleBackColor = false;
            this.setting.Click += new System.EventHandler(this.setting_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // tb_bookTableAdapter
            // 
            this.tb_bookTableAdapter.ClearBeforeFill = true;
            // 
            // tb_UserTableAdapter
            // 
            this.tb_UserTableAdapter.ClearBeforeFill = true;
            // 
            // tbbookBindingSource1
            // 
            this.tbbookBindingSource1.DataMember = "tb_book";
            this.tbbookBindingSource1.DataSource = this.db_libaryDataSet;
            // 
            // dblibaryDataSetBindingSource
            // 
            this.dblibaryDataSetBindingSource.DataSource = this.db_libaryDataSet;
            this.dblibaryDataSetBindingSource.Position = 0;
            // 
            // db_libaryDataSet1
            // 
            this.db_libaryDataSet1.DataSetName = "db_libaryDataSet1";
            this.db_libaryDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbquestionBindingSource
            // 
            this.tbquestionBindingSource.DataMember = "tb_question";
            this.tbquestionBindingSource.DataSource = this.db_libaryDataSet1;
            // 
            // tb_questionTableAdapter
            // 
            this.tb_questionTableAdapter.ClearBeforeFill = true;
            // 
            // tb_questionTableAdapter1
            // 
            this.tb_questionTableAdapter1.ClearBeforeFill = true;
            // 
            // UImain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(992, 615);
            this.CloseDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_down;
            this.CloseMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_highlight;
            this.CloseNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_disable;
            this.Controls.Add(this.setting);
            this.Controls.Add(this.main);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaxDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_max_down;
            this.MaxMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_max_highlight;
            this.MaxNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_max_normal;
            this.MiniDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_down;
            this.MiniMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_highlight;
            this.MiniNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_normal;
            this.Name = "UImain";
            this.RestoreDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_restore_down;
            this.RestoreMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_restore_highlight;
            this.RestoreNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_restore_normal;
            this.ShowDrawIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "";
            this.Activated += new System.EventHandler(this.UImain_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UImain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.UImain_FormClosed);
            this.Load += new System.EventHandler(this.UImain_Load);
            this.main.ResumeLayout(false);
            this.firstpage.ResumeLayout(false);
            this.firstpageitem.ResumeLayout(false);
            this.userinfo.ResumeLayout(false);
            this.userinfo.PerformLayout();
            this.message.ResumeLayout(false);
            this.skinPanel5.ResumeLayout(false);
            this.bookstore.ResumeLayout(false);
            this.skinSplitContainer1.Panel1.ResumeLayout(false);
            this.skinSplitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer1)).EndInit();
            this.skinSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.booklist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbbookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet)).EndInit();
            this.skinPanel1.ResumeLayout(false);
            this.skinPanel1.PerformLayout();
            this.skinPanel6.ResumeLayout(false);
            this.skinPanel6.PerformLayout();
            this.skinPanel2.ResumeLayout(false);
            this.skinPanel2.PerformLayout();
            this.skinPanel7.ResumeLayout(false);
            this.skinToolStrip3.ResumeLayout(false);
            this.skinToolStrip3.PerformLayout();
            this.project.ResumeLayout(false);
            this.project.PerformLayout();
            this.skinSplitContainer2.Panel1.ResumeLayout(false);
            this.skinSplitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer2)).EndInit();
            this.skinSplitContainer2.ResumeLayout(false);
            this.skinPanel12.ResumeLayout(false);
            this.skinPanel12.PerformLayout();
            this.skinPanel11.ResumeLayout(false);
            this.skinPanel11.PerformLayout();
            this.skinPanel10.ResumeLayout(false);
            this.skinPanel10.PerformLayout();
            this.skinPanelQuestion.ResumeLayout(false);
            this.skinPanelQuestion.PerformLayout();
            this.skinPanelAnswer.ResumeLayout(false);
            this.skinPanelAnswer.PerformLayout();
            this.skinToolStrip4.ResumeLayout(false);
            this.skinToolStrip4.PerformLayout();
            this.root.ResumeLayout(false);
            this.rootcontrol.ResumeLayout(false);
            this.bookmanage.ResumeLayout(false);
            this.bookmanage.PerformLayout();
            this.skinPanel3.ResumeLayout(false);
            this.skinPanel4.ResumeLayout(false);
            this.skinPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookinfolist)).EndInit();
            this.skinToolStrip1.ResumeLayout(false);
            this.skinToolStrip1.PerformLayout();
            this.skinPanel8.ResumeLayout(false);
            this.skinPanel8.PerformLayout();
            this.projectmanage.ResumeLayout(false);
            this.skinTabControl1.ResumeLayout(false);
            this.questioncontrol.ResumeLayout(false);
            this.questioncontrol.PerformLayout();
            this.skinToolStrip5.ResumeLayout(false);
            this.skinToolStrip5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.questionControlList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquestionBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet3)).EndInit();
            this.usermanage.ResumeLayout(false);
            this.usermanage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userinfolist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbUserBindingSource)).EndInit();
            this.settingmenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tbbookBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibaryDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_libaryDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquestionBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CCWin.SkinControl.SkinTabControl main;
        private System.Windows.Forms.ImageList imageList1;
        private CCWin.SkinControl.SkinTabPage firstpage;
        private CCWin.SkinControl.SkinTabPage bookstore;
        private CCWin.SkinControl.SkinTabPage project;
        private CCWin.SkinControl.SkinTabPage root;
        private CCWin.SkinControl.SkinTabControl rootcontrol;
        private CCWin.SkinControl.SkinTabPage bookmanage;
        private CCWin.SkinControl.SkinTabPage projectmanage;
        private CCWin.SkinControl.SkinTabPage usermanage;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer1;
        private CCWin.SkinControl.SkinTreeView skinTreeView1;
        private CCWin.SkinControl.SkinTabControl firstpageitem;
        private CCWin.SkinControl.SkinTabPage userinfo;
        private CCWin.SkinControl.SkinTabPage message;
        private CCWin.SkinControl.SkinLabel skinLabel8;
        private CCWin.SkinControl.SkinButton fresh;
        private System.Windows.Forms.Panel head;
        private CCWin.SkinControl.SkinLabel skinLabel14;
        private CCWin.SkinControl.SkinLabel skinLabel13;
        private CCWin.SkinControl.SkinLabel skinLabel12;
        private CCWin.SkinControl.SkinLabel skinLabel11;
        private CCWin.SkinControl.SkinLabel skinLabel10;
        private CCWin.SkinControl.SkinLabel qq;
        private CCWin.SkinControl.SkinLabel phone;
        private CCWin.SkinControl.SkinLabel userid;
        private CCWin.SkinControl.SkinLabel username;
        private CCWin.SkinControl.SkinLabel nameshow;
        private CCWin.SkinControl.SkinContextMenuStrip settingmenu;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 登出ToolStripMenuItem;
        private CCWin.SkinControl.SkinButton setting;
        private CCWin.SkinControl.SkinDataGridView userinfolist;
        private CCWin.SkinControl.SkinButton adduser;
        private CCWin.SkinControl.SkinButton deletuser;
        private CCWin.SkinControl.SkinPanel skinPanel1;
        private CCWin.SkinControl.SkinComboBox booktype;
        private CCWin.SkinControl.SkinButton booklistsearch;
        private CCWin.SkinControl.SkinTextBox booksearch;
        private CCWin.SkinControl.SkinLabel skinLabel9;
        private CCWin.SkinControl.SkinDataGridView booklist;
        private db_libaryDataSet db_libaryDataSet;
        private System.Windows.Forms.BindingSource tbbookBindingSource;
        private db_libaryDataSetTableAdapters.tb_bookTableAdapter tb_bookTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn autorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pubnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tbUserBindingSource;
        private db_libaryDataSetTableAdapters.tb_UserTableAdapter tb_UserTableAdapter;
        private System.Windows.Forms.BindingSource tbbookBindingSource1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private CCWin.SkinControl.SkinLabel leveltext;
        private CCWin.SkinControl.SkinLabel skinLabel15;
        private System.Windows.Forms.Timer timer1;
        private CCWin.SkinControl.SkinPanel skinPanel5;
        private CCWin.SkinControl.SkinPanel skinPanel6;
        private CCWin.SkinControl.SkinLabel skinLabel21;
        private CCWin.SkinControl.SkinLabel skinLabel20;
        private CCWin.SkinControl.SkinTextBox bookIntro;
        private CCWin.SkinControl.SkinLabel skinLabel19;
        private CCWin.SkinControl.SkinLabel skinLabel18;
        private CCWin.SkinControl.SkinLabel skinLabel17;
        private CCWin.SkinControl.SkinLabel skinLabel16;
        private CCWin.SkinControl.SkinTextBox personalSign;
        private CCWin.SkinControl.SkinLabel skinLabel22;
        private System.Windows.Forms.LinkLabel userInfoCancle;
        private System.Windows.Forms.LinkLabel userInfoSure;
        private System.Windows.Forms.LinkLabel uerInformChange;
        private CCWin.SkinControl.SkinTextBox qqChange;
        private CCWin.SkinControl.SkinTextBox phoneChange;
        private CCWin.SkinControl.SkinTextBox userNameChange;
        private CCWin.SkinControl.SkinLabel booksorted;
        private CCWin.SkinControl.SkinLabel bookPubname;
        private CCWin.SkinControl.SkinLabel bookauthor;
        private CCWin.SkinControl.SkinLabel bookName;
        private CCWin.SkinControl.SkinPanel skinPanel3;
        private CCWin.SkinControl.SkinPanel skinPanel4;
        private CCWin.SkinControl.SkinDataGridView bookinfolist;
        private CCWin.SkinControl.SkinToolStrip skinToolStrip1;
        private System.Windows.Forms.ToolStripButton bookadd;
        private System.Windows.Forms.ToolStripButton bookdelet;
        private System.Windows.Forms.ToolStripButton bookrefrsh;
        private CCWin.SkinControl.SkinPanel skinPanel8;
        private CCWin.SkinControl.SkinTextBox bookmanagekey;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private CCWin.SkinControl.SkinComboBox booksearchtype;
        private CCWin.SkinControl.SkinButton bookmanagesearch;
        private CCWin.SkinControl.SkinButton skinButton3;
        private CCWin.SkinControl.SkinLabel bookdate;
        private CCWin.SkinControl.SkinLabel bookprice;
        private CCWin.SkinControl.SkinLabel bookpage;
        private CCWin.SkinControl.SkinLabel skinLabel24;
        private CCWin.SkinControl.SkinLabel skinLabel7;
        private CCWin.SkinControl.SkinLabel skinLabel23;
        private CCWin.SkinControl.SkinPanel bookPicture;
        private CCWin.SkinControl.SkinPanel skinPanelAnswer;
        private CCWin.SkinControl.SkinButton answerUpload;
        private CCWin.SkinControl.SkinLabel answerLoad;
        private CCWin.SkinControl.SkinButton chooseAnswerFile;
        private CCWin.SkinControl.SkinLabel skinLabel26;
        private CCWin.SkinControl.SkinTextBox answerIntro;
        private CCWin.SkinControl.SkinLabel skinLabel27;
        private CCWin.SkinControl.SkinPanel skinPanel10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn selectuser;
        private System.Windows.Forms.DataGridViewButtonColumn levelchange;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subjectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qqDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn levelDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrownumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn onlineDataGridViewCheckBoxColumn;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer2;
        private System.Windows.Forms.BindingSource dblibaryDataSetBindingSource;
        private db_libaryDataSet1 db_libaryDataSet1;
        private System.Windows.Forms.BindingSource tbquestionBindingSource;
        private db_libaryDataSet1TableAdapters.tb_questionTableAdapter tb_questionTableAdapter;
        private CCWin.SkinControl.SkinFlowLayoutPanel commentList;
        private CCWin.SkinControl.SkinPanel skinPanel2;
        private CCWin.SkinControl.SkinPanel skinPanel7;
        private CCWin.SkinControl.SkinButton commentUpload;
        private CCWin.SkinControl.SkinTextBox commentText;
        private CCWin.SkinControl.SkinToolStrip skinToolStrip3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn bookselect;
        private System.Windows.Forms.DataGridViewButtonColumn bookinfoset;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn autorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pubnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pagecodeDataGridViewTextBoxColumn;
        private CCWin.SkinControl.SkinPanel skinPanelQuestion;
        private CCWin.SkinControl.SkinButton questionUpload;
        private CCWin.SkinControl.SkinLabel questionLoad;
        private CCWin.SkinControl.SkinButton chooseQusetionFile;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private CCWin.SkinControl.SkinTextBox questionIntro;
        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinComboBox questionType;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinTextBox questionTitle;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinToolStrip skinToolStrip4;
        private CCWin.SkinControl.SkinPanel skinPanel11;
        private CCWin.SkinControl.SkinLabel contentword;
        private CCWin.SkinControl.SkinLabel questiondate;
        private CCWin.SkinControl.SkinLabel questioner;
        private CCWin.SkinControl.SkinLabel contenttitle;
        private CCWin.SkinControl.SkinFlowLayoutPanel answer_Content;
        private CCWin.SkinControl.SkinPanel questionerImg;
        private CCWin.SkinControl.SkinFlowLayoutPanel ask_Content;
        private CCWin.SkinControl.SkinPanel skinPanel12;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinComboBox questionlistType;
        private CCWin.SkinControl.SkinButton skinButton1;
        private CCWin.SkinControl.SkinLabel fileName;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.ToolStripButton questionshow;
        private System.Windows.Forms.ToolStripButton answershow;
        private CCWin.SkinControl.SkinTabControl skinTabControl1;
        private CCWin.SkinControl.SkinTabPage questioncontrol;
        private CCWin.SkinControl.SkinDataGridView questionControlList;
        private CCWin.SkinControl.SkinTabPage answercontrol;
        private db_libaryDataSet3 db_libaryDataSet3;
        private System.Windows.Forms.BindingSource tbquestionBindingSource1;
        private db_libaryDataSet3TableAdapters.tb_questionTableAdapter tb_questionTableAdapter1;
        private CCWin.SkinControl.SkinToolStrip skinToolStrip5;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn select;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn aboutDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn filenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uploadTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn questionerIdDataGridViewTextBoxColumn;
        private CCWin.SkinControl.SkinLabel Typeword;
        private CCWin.SkinControl.SkinFlowLayoutPanel answerRemindPanel;
        private CCWin.SkinControl.SkinLabel lastOnline;
        private CCWin.SkinControl.SkinLabel skinLabel28;
    }
}