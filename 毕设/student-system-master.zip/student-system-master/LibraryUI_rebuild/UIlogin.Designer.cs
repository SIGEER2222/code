﻿namespace LibraryUI_rebuild
{
    partial class UIlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UIlogin));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.userid = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox1 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel1 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox1 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPanel2 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox2 = new CCWin.SkinControl.SkinPictureBox();
            this.stuname = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox2 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel3 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox3 = new CCWin.SkinControl.SkinPictureBox();
            this.stuid = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox3 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel4 = new CCWin.SkinControl.SkinPanel();
            this.courage = new CCWin.SkinControl.SkinComboBox();
            this.skinPictureBox4 = new CCWin.SkinControl.SkinPictureBox();
            this.skinPanel5 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox5 = new CCWin.SkinControl.SkinPictureBox();
            this.password = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox5 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel6 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox6 = new CCWin.SkinControl.SkinPictureBox();
            this.repassword = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox6 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel7 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox7 = new CCWin.SkinControl.SkinPictureBox();
            this.phone = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox7 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPanel8 = new CCWin.SkinControl.SkinPanel();
            this.skinPictureBox8 = new CCWin.SkinControl.SkinPictureBox();
            this.qq = new CCWin.SkinControl.SkinTextBox();
            this.skinWaterTextBox8 = new CCWin.SkinControl.SkinWaterTextBox();
            this.head = new System.Windows.Forms.Panel();
            this.sure = new CCWin.SkinControl.SkinButton();
            this.cancle = new CCWin.SkinControl.SkinButton();
            this.passwordcheck = new System.Windows.Forms.Label();
            this.userid.SuspendLayout();
            this.skinPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox1)).BeginInit();
            this.skinPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox2)).BeginInit();
            this.stuname.SuspendLayout();
            this.skinPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox3)).BeginInit();
            this.stuid.SuspendLayout();
            this.skinPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox4)).BeginInit();
            this.skinPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox5)).BeginInit();
            this.password.SuspendLayout();
            this.skinPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox6)).BeginInit();
            this.repassword.SuspendLayout();
            this.skinPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox7)).BeginInit();
            this.phone.SuspendLayout();
            this.skinPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox8)).BeginInit();
            this.qq.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(147, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 35;
            this.label1.Text = "拍照上传";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(211, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "本地上传";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // userid
            // 
            this.userid.BackColor = System.Drawing.Color.Transparent;
            this.userid.Controls.Add(this.skinWaterTextBox1);
            this.userid.DownBack = null;
            this.userid.Icon = null;
            this.userid.IconIsButton = false;
            this.userid.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.userid.IsPasswordChat = '\0';
            this.userid.IsSystemPasswordChar = false;
            this.userid.Lines = new string[0];
            this.userid.Location = new System.Drawing.Point(28, 0);
            this.userid.Margin = new System.Windows.Forms.Padding(0);
            this.userid.MaxLength = 32767;
            this.userid.MinimumSize = new System.Drawing.Size(28, 28);
            this.userid.MouseBack = null;
            this.userid.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.userid.Multiline = false;
            this.userid.Name = "userid";
            this.userid.NormlBack = null;
            this.userid.Padding = new System.Windows.Forms.Padding(5);
            this.userid.ReadOnly = false;
            this.userid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userid.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.userid.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.userid.SkinTxt.Name = "BaseText";
            this.userid.SkinTxt.TabIndex = 0;
            this.userid.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.userid.SkinTxt.WaterText = "用户名";
            this.userid.TabIndex = 37;
            this.userid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.userid.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.userid.WaterText = "用户名";
            this.userid.WordWrap = true;
            // 
            // skinWaterTextBox1
            // 
            this.skinWaterTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox1.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox1.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox1.Name = "skinWaterTextBox1";
            this.skinWaterTextBox1.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox1.TabIndex = 1;
            this.skinWaterTextBox1.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox1.WaterText = "用户名";
            // 
            // skinPanel1
            // 
            this.skinPanel1.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel1.Controls.Add(this.skinPictureBox1);
            this.skinPanel1.Controls.Add(this.userid);
            this.skinPanel1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel1.DownBack = null;
            this.skinPanel1.Location = new System.Drawing.Point(23, 183);
            this.skinPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel1.MouseBack = null;
            this.skinPanel1.Name = "skinPanel1";
            this.skinPanel1.NormlBack = null;
            this.skinPanel1.Size = new System.Drawing.Size(175, 28);
            this.skinPanel1.TabIndex = 39;
            // 
            // skinPictureBox1
            // 
            this.skinPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox1.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.user_white;
            this.skinPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox1.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox1.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox1.Name = "skinPictureBox1";
            this.skinPictureBox1.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox1.TabIndex = 38;
            this.skinPictureBox1.TabStop = false;
            // 
            // skinPanel2
            // 
            this.skinPanel2.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel2.Controls.Add(this.skinPictureBox2);
            this.skinPanel2.Controls.Add(this.stuname);
            this.skinPanel2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel2.DownBack = null;
            this.skinPanel2.Location = new System.Drawing.Point(23, 224);
            this.skinPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel2.MouseBack = null;
            this.skinPanel2.Name = "skinPanel2";
            this.skinPanel2.NormlBack = null;
            this.skinPanel2.Size = new System.Drawing.Size(175, 28);
            this.skinPanel2.TabIndex = 40;
            // 
            // skinPictureBox2
            // 
            this.skinPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox2.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.user_2_white;
            this.skinPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox2.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox2.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox2.Name = "skinPictureBox2";
            this.skinPictureBox2.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox2.TabIndex = 38;
            this.skinPictureBox2.TabStop = false;
            // 
            // stuname
            // 
            this.stuname.BackColor = System.Drawing.Color.Transparent;
            this.stuname.Controls.Add(this.skinWaterTextBox2);
            this.stuname.DownBack = null;
            this.stuname.Icon = null;
            this.stuname.IconIsButton = false;
            this.stuname.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.stuname.IsPasswordChat = '\0';
            this.stuname.IsSystemPasswordChar = false;
            this.stuname.Lines = new string[0];
            this.stuname.Location = new System.Drawing.Point(28, 0);
            this.stuname.Margin = new System.Windows.Forms.Padding(0);
            this.stuname.MaxLength = 32767;
            this.stuname.MinimumSize = new System.Drawing.Size(28, 28);
            this.stuname.MouseBack = null;
            this.stuname.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.stuname.Multiline = false;
            this.stuname.Name = "stuname";
            this.stuname.NormlBack = null;
            this.stuname.Padding = new System.Windows.Forms.Padding(5);
            this.stuname.ReadOnly = false;
            this.stuname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.stuname.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.stuname.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.stuname.SkinTxt.Name = "BaseText";
            this.stuname.SkinTxt.TabIndex = 0;
            this.stuname.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.stuname.SkinTxt.WaterText = "姓名";
            this.stuname.TabIndex = 37;
            this.stuname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.stuname.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.stuname.WaterText = "姓名";
            this.stuname.WordWrap = true;
            // 
            // skinWaterTextBox2
            // 
            this.skinWaterTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox2.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox2.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox2.Name = "skinWaterTextBox2";
            this.skinWaterTextBox2.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox2.TabIndex = 1;
            this.skinWaterTextBox2.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox2.WaterText = "姓名";
            // 
            // skinPanel3
            // 
            this.skinPanel3.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel3.Controls.Add(this.skinPictureBox3);
            this.skinPanel3.Controls.Add(this.stuid);
            this.skinPanel3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel3.DownBack = null;
            this.skinPanel3.Location = new System.Drawing.Point(23, 266);
            this.skinPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel3.MouseBack = null;
            this.skinPanel3.Name = "skinPanel3";
            this.skinPanel3.NormlBack = null;
            this.skinPanel3.Size = new System.Drawing.Size(175, 28);
            this.skinPanel3.TabIndex = 40;
            // 
            // skinPictureBox3
            // 
            this.skinPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox3.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.user_card_white;
            this.skinPictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox3.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox3.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox3.Name = "skinPictureBox3";
            this.skinPictureBox3.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox3.TabIndex = 38;
            this.skinPictureBox3.TabStop = false;
            // 
            // stuid
            // 
            this.stuid.BackColor = System.Drawing.Color.Transparent;
            this.stuid.Controls.Add(this.skinWaterTextBox3);
            this.stuid.DownBack = null;
            this.stuid.Icon = null;
            this.stuid.IconIsButton = false;
            this.stuid.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.stuid.IsPasswordChat = '\0';
            this.stuid.IsSystemPasswordChar = false;
            this.stuid.Lines = new string[0];
            this.stuid.Location = new System.Drawing.Point(28, 0);
            this.stuid.Margin = new System.Windows.Forms.Padding(0);
            this.stuid.MaxLength = 32767;
            this.stuid.MinimumSize = new System.Drawing.Size(28, 28);
            this.stuid.MouseBack = null;
            this.stuid.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.stuid.Multiline = false;
            this.stuid.Name = "stuid";
            this.stuid.NormlBack = null;
            this.stuid.Padding = new System.Windows.Forms.Padding(5);
            this.stuid.ReadOnly = false;
            this.stuid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.stuid.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.stuid.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.stuid.SkinTxt.Name = "BaseText";
            this.stuid.SkinTxt.TabIndex = 0;
            this.stuid.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.stuid.SkinTxt.WaterText = "学号";
            this.stuid.TabIndex = 37;
            this.stuid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.stuid.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.stuid.WaterText = "学号";
            this.stuid.WordWrap = true;
            // 
            // skinWaterTextBox3
            // 
            this.skinWaterTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox3.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox3.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox3.Name = "skinWaterTextBox3";
            this.skinWaterTextBox3.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox3.TabIndex = 1;
            this.skinWaterTextBox3.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox3.WaterText = "学号";
            // 
            // skinPanel4
            // 
            this.skinPanel4.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel4.Controls.Add(this.courage);
            this.skinPanel4.Controls.Add(this.skinPictureBox4);
            this.skinPanel4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel4.DownBack = null;
            this.skinPanel4.Location = new System.Drawing.Point(23, 309);
            this.skinPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel4.MouseBack = null;
            this.skinPanel4.Name = "skinPanel4";
            this.skinPanel4.NormlBack = null;
            this.skinPanel4.Size = new System.Drawing.Size(175, 28);
            this.skinPanel4.TabIndex = 41;
            // 
            // courage
            // 
            this.courage.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.courage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.courage.FormattingEnabled = true;
            this.courage.Items.AddRange(new object[] {
            "机械工程学院",
            "计算机学院",
            "通信工程学院",
            "美术学院",
            "人文学院"});
            this.courage.Location = new System.Drawing.Point(28, 4);
            this.courage.Margin = new System.Windows.Forms.Padding(0);
            this.courage.Name = "courage";
            this.courage.Size = new System.Drawing.Size(147, 22);
            this.courage.TabIndex = 39;
            this.courage.WaterText = "学院";
            // 
            // skinPictureBox4
            // 
            this.skinPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox4.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.store_white;
            this.skinPictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox4.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox4.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox4.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox4.Name = "skinPictureBox4";
            this.skinPictureBox4.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox4.TabIndex = 38;
            this.skinPictureBox4.TabStop = false;
            // 
            // skinPanel5
            // 
            this.skinPanel5.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel5.Controls.Add(this.skinPictureBox5);
            this.skinPanel5.Controls.Add(this.password);
            this.skinPanel5.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel5.DownBack = null;
            this.skinPanel5.Location = new System.Drawing.Point(213, 183);
            this.skinPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel5.MouseBack = null;
            this.skinPanel5.Name = "skinPanel5";
            this.skinPanel5.NormlBack = null;
            this.skinPanel5.Size = new System.Drawing.Size(175, 28);
            this.skinPanel5.TabIndex = 42;
            // 
            // skinPictureBox5
            // 
            this.skinPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox5.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.key_white;
            this.skinPictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox5.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox5.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox5.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox5.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox5.Name = "skinPictureBox5";
            this.skinPictureBox5.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox5.TabIndex = 38;
            this.skinPictureBox5.TabStop = false;
            // 
            // password
            // 
            this.password.BackColor = System.Drawing.Color.Transparent;
            this.password.Controls.Add(this.skinWaterTextBox5);
            this.password.DownBack = null;
            this.password.Icon = null;
            this.password.IconIsButton = false;
            this.password.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.password.IsPasswordChat = '●';
            this.password.IsSystemPasswordChar = true;
            this.password.Lines = new string[0];
            this.password.Location = new System.Drawing.Point(28, 0);
            this.password.Margin = new System.Windows.Forms.Padding(0);
            this.password.MaxLength = 32767;
            this.password.MinimumSize = new System.Drawing.Size(28, 28);
            this.password.MouseBack = null;
            this.password.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.password.Multiline = false;
            this.password.Name = "password";
            this.password.NormlBack = null;
            this.password.Padding = new System.Windows.Forms.Padding(5);
            this.password.ReadOnly = false;
            this.password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.password.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.password.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.password.SkinTxt.Name = "BaseText";
            this.password.SkinTxt.PasswordChar = '●';
            this.password.SkinTxt.TabIndex = 0;
            this.password.SkinTxt.UseSystemPasswordChar = true;
            this.password.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.password.SkinTxt.WaterText = "密码";
            this.password.TabIndex = 37;
            this.password.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.password.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.password.WaterText = "密码";
            this.password.WordWrap = true;
            this.password.Leave += new System.EventHandler(this.password_Leave);
            // 
            // skinWaterTextBox5
            // 
            this.skinWaterTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox5.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox5.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox5.Name = "skinWaterTextBox5";
            this.skinWaterTextBox5.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox5.TabIndex = 1;
            this.skinWaterTextBox5.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox5.WaterText = "用户名";
            // 
            // skinPanel6
            // 
            this.skinPanel6.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel6.Controls.Add(this.skinPictureBox6);
            this.skinPanel6.Controls.Add(this.repassword);
            this.skinPanel6.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel6.DownBack = null;
            this.skinPanel6.Location = new System.Drawing.Point(213, 224);
            this.skinPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel6.MouseBack = null;
            this.skinPanel6.Name = "skinPanel6";
            this.skinPanel6.NormlBack = null;
            this.skinPanel6.Size = new System.Drawing.Size(175, 28);
            this.skinPanel6.TabIndex = 43;
            // 
            // skinPictureBox6
            // 
            this.skinPictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox6.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.key_white;
            this.skinPictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox6.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox6.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox6.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox6.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox6.Name = "skinPictureBox6";
            this.skinPictureBox6.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox6.TabIndex = 38;
            this.skinPictureBox6.TabStop = false;
            // 
            // repassword
            // 
            this.repassword.BackColor = System.Drawing.Color.Transparent;
            this.repassword.Controls.Add(this.skinWaterTextBox6);
            this.repassword.DownBack = null;
            this.repassword.Icon = null;
            this.repassword.IconIsButton = false;
            this.repassword.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.repassword.IsPasswordChat = '●';
            this.repassword.IsSystemPasswordChar = true;
            this.repassword.Lines = new string[0];
            this.repassword.Location = new System.Drawing.Point(28, 0);
            this.repassword.Margin = new System.Windows.Forms.Padding(0);
            this.repassword.MaxLength = 32767;
            this.repassword.MinimumSize = new System.Drawing.Size(28, 28);
            this.repassword.MouseBack = null;
            this.repassword.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.repassword.Multiline = false;
            this.repassword.Name = "repassword";
            this.repassword.NormlBack = null;
            this.repassword.Padding = new System.Windows.Forms.Padding(5);
            this.repassword.ReadOnly = false;
            this.repassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.repassword.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.repassword.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.repassword.SkinTxt.Name = "BaseText";
            this.repassword.SkinTxt.PasswordChar = '●';
            this.repassword.SkinTxt.TabIndex = 0;
            this.repassword.SkinTxt.UseSystemPasswordChar = true;
            this.repassword.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.repassword.SkinTxt.WaterText = "确认密码";
            this.repassword.TabIndex = 37;
            this.repassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.repassword.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.repassword.WaterText = "确认密码";
            this.repassword.WordWrap = true;
            this.repassword.Leave += new System.EventHandler(this.repassword_Leave);
            // 
            // skinWaterTextBox6
            // 
            this.skinWaterTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox6.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox6.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox6.Name = "skinWaterTextBox6";
            this.skinWaterTextBox6.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox6.TabIndex = 1;
            this.skinWaterTextBox6.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox6.WaterText = "用户名";
            // 
            // skinPanel7
            // 
            this.skinPanel7.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel7.Controls.Add(this.skinPictureBox7);
            this.skinPanel7.Controls.Add(this.phone);
            this.skinPanel7.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel7.DownBack = null;
            this.skinPanel7.Location = new System.Drawing.Point(213, 266);
            this.skinPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel7.MouseBack = null;
            this.skinPanel7.Name = "skinPanel7";
            this.skinPanel7.NormlBack = null;
            this.skinPanel7.Size = new System.Drawing.Size(175, 28);
            this.skinPanel7.TabIndex = 40;
            // 
            // skinPictureBox7
            // 
            this.skinPictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox7.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.mail_white;
            this.skinPictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox7.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox7.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox7.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox7.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox7.Name = "skinPictureBox7";
            this.skinPictureBox7.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox7.TabIndex = 38;
            this.skinPictureBox7.TabStop = false;
            // 
            // phone
            // 
            this.phone.BackColor = System.Drawing.Color.Transparent;
            this.phone.Controls.Add(this.skinWaterTextBox7);
            this.phone.DownBack = null;
            this.phone.Icon = null;
            this.phone.IconIsButton = false;
            this.phone.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.phone.IsPasswordChat = '\0';
            this.phone.IsSystemPasswordChar = false;
            this.phone.Lines = new string[0];
            this.phone.Location = new System.Drawing.Point(28, 0);
            this.phone.Margin = new System.Windows.Forms.Padding(0);
            this.phone.MaxLength = 32767;
            this.phone.MinimumSize = new System.Drawing.Size(28, 28);
            this.phone.MouseBack = null;
            this.phone.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.phone.Multiline = false;
            this.phone.Name = "phone";
            this.phone.NormlBack = null;
            this.phone.Padding = new System.Windows.Forms.Padding(5);
            this.phone.ReadOnly = false;
            this.phone.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.phone.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.phone.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.phone.SkinTxt.Name = "BaseText";
            this.phone.SkinTxt.TabIndex = 0;
            this.phone.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.phone.SkinTxt.WaterText = "电话";
            this.phone.TabIndex = 37;
            this.phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phone.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.phone.WaterText = "电话";
            this.phone.WordWrap = true;
            // 
            // skinWaterTextBox7
            // 
            this.skinWaterTextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox7.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox7.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox7.Name = "skinWaterTextBox7";
            this.skinWaterTextBox7.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox7.TabIndex = 1;
            this.skinWaterTextBox7.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox7.WaterText = "电话";
            // 
            // skinPanel8
            // 
            this.skinPanel8.BackColor = System.Drawing.Color.Transparent;
            this.skinPanel8.Controls.Add(this.skinPictureBox8);
            this.skinPanel8.Controls.Add(this.qq);
            this.skinPanel8.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinPanel8.DownBack = null;
            this.skinPanel8.Location = new System.Drawing.Point(213, 309);
            this.skinPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.skinPanel8.MouseBack = null;
            this.skinPanel8.Name = "skinPanel8";
            this.skinPanel8.NormlBack = null;
            this.skinPanel8.Size = new System.Drawing.Size(175, 28);
            this.skinPanel8.TabIndex = 40;
            // 
            // skinPictureBox8
            // 
            this.skinPictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox8.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.polaroid_2_white;
            this.skinPictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.skinPictureBox8.Dock = System.Windows.Forms.DockStyle.Left;
            this.skinPictureBox8.InitialImage = global::LibraryUI_rebuild.Properties.Resources.user;
            this.skinPictureBox8.Location = new System.Drawing.Point(0, 0);
            this.skinPictureBox8.Margin = new System.Windows.Forms.Padding(0);
            this.skinPictureBox8.Name = "skinPictureBox8";
            this.skinPictureBox8.Size = new System.Drawing.Size(28, 28);
            this.skinPictureBox8.TabIndex = 38;
            this.skinPictureBox8.TabStop = false;
            // 
            // qq
            // 
            this.qq.BackColor = System.Drawing.Color.Transparent;
            this.qq.Controls.Add(this.skinWaterTextBox8);
            this.qq.DownBack = null;
            this.qq.Icon = null;
            this.qq.IconIsButton = false;
            this.qq.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.qq.IsPasswordChat = '\0';
            this.qq.IsSystemPasswordChar = false;
            this.qq.Lines = new string[0];
            this.qq.Location = new System.Drawing.Point(28, 0);
            this.qq.Margin = new System.Windows.Forms.Padding(0);
            this.qq.MaxLength = 32767;
            this.qq.MinimumSize = new System.Drawing.Size(28, 28);
            this.qq.MouseBack = null;
            this.qq.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.qq.Multiline = false;
            this.qq.Name = "qq";
            this.qq.NormlBack = null;
            this.qq.Padding = new System.Windows.Forms.Padding(5);
            this.qq.ReadOnly = false;
            this.qq.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.qq.Size = new System.Drawing.Size(147, 28);
            // 
            // 
            // 
            this.qq.SkinTxt.Location = new System.Drawing.Point(0, 0);
            this.qq.SkinTxt.Name = "BaseText";
            this.qq.SkinTxt.TabIndex = 0;
            this.qq.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.qq.SkinTxt.WaterText = "qq";
            this.qq.TabIndex = 37;
            this.qq.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.qq.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.qq.WaterText = "qq";
            this.qq.WordWrap = true;
            // 
            // skinWaterTextBox8
            // 
            this.skinWaterTextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinWaterTextBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinWaterTextBox8.Location = new System.Drawing.Point(5, 5);
            this.skinWaterTextBox8.Margin = new System.Windows.Forms.Padding(0);
            this.skinWaterTextBox8.Name = "skinWaterTextBox8";
            this.skinWaterTextBox8.Size = new System.Drawing.Size(137, 14);
            this.skinWaterTextBox8.TabIndex = 1;
            this.skinWaterTextBox8.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox8.WaterText = "qq";
            // 
            // head
            // 
            this.head.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources.none;
            this.head.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.head.Location = new System.Drawing.Point(155, 27);
            this.head.Name = "head";
            this.head.Size = new System.Drawing.Size(100, 100);
            this.head.TabIndex = 34;
            // 
            // sure
            // 
            this.sure.BackColor = System.Drawing.Color.Transparent;
            this.sure.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.sure.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.sure.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.sure.Location = new System.Drawing.Point(81, 361);
            this.sure.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.sure.Name = "sure";
            this.sure.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.sure.Size = new System.Drawing.Size(75, 23);
            this.sure.TabIndex = 44;
            this.sure.Text = "确认";
            this.sure.UseVisualStyleBackColor = false;
            this.sure.Click += new System.EventHandler(this.sure_Click);
            // 
            // cancle
            // 
            this.cancle.BackColor = System.Drawing.Color.Transparent;
            this.cancle.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.cancle.DownBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_down;
            this.cancle.DrawType = CCWin.SkinControl.DrawStyle.Img;
            this.cancle.Location = new System.Drawing.Point(250, 361);
            this.cancle.MouseBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_hover;
            this.cancle.Name = "cancle";
            this.cancle.NormlBack = global::LibraryUI_rebuild.Properties.Resources.button_loginchange_normal;
            this.cancle.Size = new System.Drawing.Size(75, 23);
            this.cancle.TabIndex = 45;
            this.cancle.Text = "取消";
            this.cancle.UseVisualStyleBackColor = false;
            this.cancle.Click += new System.EventHandler(this.cancle_Click);
            // 
            // passwordcheck
            // 
            this.passwordcheck.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.passwordcheck.AutoSize = true;
            this.passwordcheck.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.passwordcheck.ForeColor = System.Drawing.Color.Crimson;
            this.passwordcheck.Location = new System.Drawing.Point(219, 164);
            this.passwordcheck.Name = "passwordcheck";
            this.passwordcheck.Size = new System.Drawing.Size(0, 12);
            this.passwordcheck.TabIndex = 29;
            // 
            // UIlogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::LibraryUI_rebuild.Properties.Resources._21;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BackShade = false;
            this.ClientSize = new System.Drawing.Size(406, 403);
            this.CloseDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_down;
            this.CloseMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_highlight;
            this.CloseNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_close_disable;
            this.Controls.Add(this.passwordcheck);
            this.Controls.Add(this.cancle);
            this.Controls.Add(this.sure);
            this.Controls.Add(this.skinPanel8);
            this.Controls.Add(this.skinPanel7);
            this.Controls.Add(this.skinPanel6);
            this.Controls.Add(this.skinPanel5);
            this.Controls.Add(this.skinPanel4);
            this.Controls.Add(this.skinPanel3);
            this.Controls.Add(this.skinPanel2);
            this.Controls.Add(this.skinPanel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.head);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MiniDownBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_down;
            this.MiniMouseBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_highlight;
            this.MiniNormlBack = global::LibraryUI_rebuild.Properties.Resources.btn_mini_normal;
            this.Name = "UIlogin";
            this.ShowDrawIcon = false;
            this.Text = "";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UIlogin_FormClosing);
            this.userid.ResumeLayout(false);
            this.userid.PerformLayout();
            this.skinPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox1)).EndInit();
            this.skinPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox2)).EndInit();
            this.stuname.ResumeLayout(false);
            this.stuname.PerformLayout();
            this.skinPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox3)).EndInit();
            this.stuid.ResumeLayout(false);
            this.stuid.PerformLayout();
            this.skinPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox4)).EndInit();
            this.skinPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox5)).EndInit();
            this.password.ResumeLayout(false);
            this.password.PerformLayout();
            this.skinPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox6)).EndInit();
            this.repassword.ResumeLayout(false);
            this.repassword.PerformLayout();
            this.skinPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox7)).EndInit();
            this.phone.ResumeLayout(false);
            this.phone.PerformLayout();
            this.skinPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox8)).EndInit();
            this.qq.ResumeLayout(false);
            this.qq.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel head;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private CCWin.SkinControl.SkinTextBox userid;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox1;
        private CCWin.SkinControl.SkinPanel skinPanel1;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox1;
        private CCWin.SkinControl.SkinPanel skinPanel2;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox2;
        private CCWin.SkinControl.SkinTextBox stuname;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox2;
        private CCWin.SkinControl.SkinPanel skinPanel3;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox3;
        private CCWin.SkinControl.SkinTextBox stuid;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox3;
        private CCWin.SkinControl.SkinPanel skinPanel4;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox4;
        private CCWin.SkinControl.SkinPanel skinPanel5;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox5;
        private CCWin.SkinControl.SkinTextBox password;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox5;
        private CCWin.SkinControl.SkinPanel skinPanel6;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox6;
        private CCWin.SkinControl.SkinTextBox repassword;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox6;
        private CCWin.SkinControl.SkinPanel skinPanel7;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox7;
        private CCWin.SkinControl.SkinTextBox phone;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox7;
        private CCWin.SkinControl.SkinPanel skinPanel8;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox8;
        private CCWin.SkinControl.SkinTextBox qq;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox8;
        private CCWin.SkinControl.SkinComboBox courage;
        private CCWin.SkinControl.SkinButton sure;
        private CCWin.SkinControl.SkinButton cancle;
        private System.Windows.Forms.Label passwordcheck;
    }
}