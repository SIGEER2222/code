﻿namespace LibrarySET
{
    partial class answerSample
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.date = new CCWin.SkinControl.SkinLabel();
            this.floor = new CCWin.SkinControl.SkinLabel();
            this.comment = new CCWin.SkinControl.SkinLabel();
            this.user = new CCWin.SkinControl.SkinLabel();
            this.Img = new CCWin.SkinControl.SkinPanel();
            this.fileName = new CCWin.SkinControl.SkinLabel();
            this.dowenload = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // skinLabel3
            // 
            this.skinLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.ForeColor = System.Drawing.Color.Black;
            this.skinLabel3.Location = new System.Drawing.Point(366, 65);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(20, 17);
            this.skinLabel3.TabIndex = 9;
            this.skinLabel3.Text = "楼";
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.BackColor = System.Drawing.Color.Transparent;
            this.date.BorderColor = System.Drawing.Color.White;
            this.date.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.date.ForeColor = System.Drawing.Color.Gray;
            this.date.Location = new System.Drawing.Point(206, 65);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(69, 17);
            this.date.TabIndex = 11;
            this.date.Text = "skinLabel1";
            // 
            // floor
            // 
            this.floor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.floor.AutoSize = true;
            this.floor.BackColor = System.Drawing.Color.Transparent;
            this.floor.BorderColor = System.Drawing.Color.LightBlue;
            this.floor.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.floor.ForeColor = System.Drawing.Color.Blue;
            this.floor.Location = new System.Drawing.Point(352, 65);
            this.floor.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.floor.Name = "floor";
            this.floor.Size = new System.Drawing.Size(20, 17);
            this.floor.TabIndex = 10;
            this.floor.Text = "楼";
            // 
            // comment
            // 
            this.comment.AutoSize = true;
            this.comment.BackColor = System.Drawing.Color.Transparent;
            this.comment.BorderColor = System.Drawing.Color.White;
            this.comment.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comment.ForeColor = System.Drawing.Color.Black;
            this.comment.Location = new System.Drawing.Point(83, 30);
            this.comment.Name = "comment";
            this.comment.Size = new System.Drawing.Size(69, 17);
            this.comment.TabIndex = 8;
            this.comment.Text = "skinLabel2";
            // 
            // user
            // 
            this.user.AutoSize = true;
            this.user.BackColor = System.Drawing.Color.Transparent;
            this.user.BorderColor = System.Drawing.Color.LightGray;
            this.user.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.user.ForeColor = System.Drawing.Color.Black;
            this.user.Location = new System.Drawing.Point(83, 7);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(73, 17);
            this.user.TabIndex = 7;
            this.user.Text = "skinLabel1";
            // 
            // Img
            // 
            this.Img.BackColor = System.Drawing.Color.Transparent;
            this.Img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Img.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.Img.DownBack = null;
            this.Img.Location = new System.Drawing.Point(12, 7);
            this.Img.MouseBack = null;
            this.Img.Name = "Img";
            this.Img.NormlBack = null;
            this.Img.Size = new System.Drawing.Size(65, 65);
            this.Img.TabIndex = 6;
            // 
            // fileName
            // 
            this.fileName.AutoSize = true;
            this.fileName.BackColor = System.Drawing.Color.Transparent;
            this.fileName.BorderColor = System.Drawing.Color.White;
            this.fileName.Font = new System.Drawing.Font("微软雅黑 Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fileName.ForeColor = System.Drawing.Color.Black;
            this.fileName.Location = new System.Drawing.Point(83, 65);
            this.fileName.Name = "fileName";
            this.fileName.Size = new System.Drawing.Size(65, 17);
            this.fileName.TabIndex = 12;
            this.fileName.Text = "skinLabel2";
            // 
            // dowenload
            // 
            this.dowenload.AutoSize = true;
            this.dowenload.Location = new System.Drawing.Point(159, 68);
            this.dowenload.Name = "dowenload";
            this.dowenload.Size = new System.Drawing.Size(29, 12);
            this.dowenload.TabIndex = 13;
            this.dowenload.TabStop = true;
            this.dowenload.Text = "下载";
            this.dowenload.Visible = false;
            this.dowenload.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dowenload_LinkClicked);
            // 
            // answerSample
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.BackgroundImage = global::LibrarySET.Properties.Resources.afgxvxsdgfgf;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.dowenload);
            this.Controls.Add(this.fileName);
            this.Controls.Add(this.skinLabel3);
            this.Controls.Add(this.date);
            this.Controls.Add(this.floor);
            this.Controls.Add(this.comment);
            this.Controls.Add(this.user);
            this.Controls.Add(this.Img);
            this.Name = "answerSample";
            this.Size = new System.Drawing.Size(394, 89);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinLabel date;
        private CCWin.SkinControl.SkinLabel floor;
        private CCWin.SkinControl.SkinLabel comment;
        private CCWin.SkinControl.SkinLabel user;
        private CCWin.SkinControl.SkinPanel Img;
        private CCWin.SkinControl.SkinLabel fileName;
        private System.Windows.Forms.LinkLabel dowenload;
    }
}
