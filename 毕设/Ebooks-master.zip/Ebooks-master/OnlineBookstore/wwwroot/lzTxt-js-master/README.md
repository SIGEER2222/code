# lzTxt-js

>js基础版访问：index.html
美化版访问：demo.html

>优化后添加的功能有：
1.将电子书的处理过程进行了封装。
2.添加翻页动画。
3.添加绘制的字体可选。
4.添加绘制的颜色可选。

>[demo](http://www.lzuntalented.cn/txt/demo.html)

>美化后的截图：
![选择书籍](http://upload-images.jianshu.io/upload_images/1031450-422e9f59236095ba.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![查看内容](http://upload-images.jianshu.io/upload_images/1031450-1784248fd01bb512.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![配置面板](http://upload-images.jianshu.io/upload_images/1031450-92702de5415c8356.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)