﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.DTO
{
    public class BooksDTO
    {
        public int id { get; set; }
        public string title { get; set; }
        public string author { get; set; }
    }
}
