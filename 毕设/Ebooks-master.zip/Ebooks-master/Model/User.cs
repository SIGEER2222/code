﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class User
    {
        public int id { get; set; }
        public string account { get; set; }
        public string password { get; set; }
        public string userName { get; set; }
    }
}
