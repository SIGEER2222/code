﻿using System;

namespace Model
{
    public class Admin
    {
        public string account { get; set; }
        public string password { get; set; }
        public string name { get; set; }
    }
}
