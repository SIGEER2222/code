﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class SQLConnection
    {
        /// <summary>
        /// 连接字符串
        /// </summary>
        public string Connecting { get; set; }
    }
}
