﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
     public class Opinion
    {
        public int id { get; set; }
        public int userid { get; set; }
        public string username { get; set; }
        public string content { get; set; }

    }
}
