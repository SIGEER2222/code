﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Valuation
    {
        public int id { get; set; } 
        public string content { get; set; }
        public string userName { get; set; }
        public int booksid { get; set; }
    }
}
