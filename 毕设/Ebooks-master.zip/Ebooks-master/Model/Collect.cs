﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public  class Collect
    {
        public int userid { get; set; }
        public int booksid { get; set; }
    }
}
