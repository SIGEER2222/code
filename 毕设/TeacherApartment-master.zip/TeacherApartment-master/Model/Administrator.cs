﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Administrator
    {
        public string account { get; set; }
        public string password { get; set; }
    }
}
