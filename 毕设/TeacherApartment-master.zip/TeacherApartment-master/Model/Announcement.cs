﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Announcement
    {
        public int id { get; set; }
        public string news { get; set; }
        public string releaseTime { get; set; }
        public string title { get; set; }
    }
}
